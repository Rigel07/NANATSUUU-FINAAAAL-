# Nanatsu Chaos (Forge 1.20.1)

Mod de Los Siete Pecados Capitales. Sube este .zip tal cual a GitHub (raiz del repo) junto con
`.github/workflows/build.yml`: Actions lo descomprime, compila y deja el .jar en Actions > Artifacts y en Releases.

Teclas: R usar habilidad, V siguiente habilidad, J menu de poderes. Sin comandos.
Los porcentajes de aparicion estan en Events.java (loot) y en data/nanatsuchaos/worldgen/placed_feature (estructuras).
