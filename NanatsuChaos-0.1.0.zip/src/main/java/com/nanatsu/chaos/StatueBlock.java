package com.nanatsu.chaos;

import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/** Estatuas de los pecados / Hawk, estatuas de arcangel (dan una Gracia) y la piedra de Excalibur. */
public class StatueBlock extends Block {
    public enum Kind { SIN, ARCHANGEL, EXCALIBUR }

    static final VoxelShape SHAPE = Block.box(3, 0, 3, 13, 15, 13);
    static final Map<String, String> TEXT = Map.of(
            "meliodas", "Meliodas, Pecado de la Ira (Dragon).",
            "diane", "Diane, Pecado de la Envidia (Serpiente).",
            "ban", "Ban, Pecado de la Avaricia (Zorro).",
            "king", "King, Pecado de la Pereza (Oso Grizzly).",
            "gowther", "Gowther, Pecado de la Lujuria (Cabra).",
            "merlin", "Merlin, Pecado de la Gula (Jabali).",
            "escanor", "Escanor, Pecado del Orgullo (Leon).",
            "hawk", "Hawk, el cerdo mas grande de la taberna. ¡Bwee!");

    final Kind kind;
    final String data;

    public StatueBlock(Properties p, Kind kind, String data) {
        super(p);
        this.kind = kind;
        this.data = data;
    }

    @Override
    public VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) {
        return SHAPE;
    }

    @Override
    public InteractionResult use(BlockState st, Level l, BlockPos pos, Player p, InteractionHand h, BlockHitResult hit) {
        if (l.isClientSide) return InteractionResult.SUCCESS;
        switch (kind) {
            case SIN -> {
                p.displayClientMessage(Component.literal("§6Estatua de " + TEXT.get(data)), true);
                if (data.equals("hawk")) l.playSound(null, pos, SoundEvents.PIG_AMBIENT, net.minecraft.sounds.SoundSource.BLOCKS, 1f, 1.5f);
            }
            case ARCHANGEL -> {
                ItemStack g = new ItemStack(Reg.I.get("gracia_" + data).get());
                if (!p.getInventory().add(g)) p.drop(g, false);
                p.sendSystemMessage(Component.literal("§e§lLa estatua del Arcangel se desvanece y te entrega su Gracia."));
                ((ServerLevel) l).sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5, 80, 0.5, 0.8, 0.5, 0.05);
                l.removeBlock(pos, false);
            }
            case EXCALIBUR -> {
                ItemStack e = new ItemStack(Reg.EXCALIBUR.get());
                if (!p.getInventory().add(e)) p.drop(e, false);
                p.sendSystemMessage(Component.literal("§b§lHas extraido Excalibur de la piedra."));
                ((ServerLevel) l).sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5, pos.getY() + 1, pos.getZ() + 0.5, 100, 0.4, 0.8, 0.4, 0.1);
                l.setBlock(pos, Blocks.COBBLESTONE.defaultBlockState(), 3);
            }
        }
        return InteractionResult.CONSUME;
    }
}
