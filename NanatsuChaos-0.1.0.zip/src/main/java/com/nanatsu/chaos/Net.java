package com.nanatsu.chaos;

import com.nanatsu.chaos.client.ClientHooks;
import java.util.List;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public class Net {
    private static final String V = "1";
    public static SimpleChannel CH;

    public record OpenRace() {}
    public record Sync(CompoundTag tag) {}
    public record Choose(int race) {}
    public record Action(int type, int arg) {}

    public static void register() {
        CH = NetworkRegistry.newSimpleChannel(new ResourceLocation(NanatsuChaos.MODID, "main"), () -> V, V::equals, V::equals);
        int id = 0;
        CH.registerMessage(id++, OpenRace.class, (m, b) -> { }, b -> new OpenRace(), (m, c) -> {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> ClientHooks::openRace));
            c.get().setPacketHandled(true);
        });
        CH.registerMessage(id++, Sync.class, (m, b) -> b.writeNbt(m.tag()), b -> new Sync(b.readNbt()), (m, c) -> {
            c.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.sync(m.tag())));
            c.get().setPacketHandled(true);
        });
        CH.registerMessage(id++, Choose.class, (m, b) -> b.writeInt(m.race()), b -> new Choose(b.readInt()), (m, c) -> {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || PD.race(p) != Race.NONE) return;
                Race[] all = Race.values();
                if (m.race() < 1 || m.race() >= all.length) return;
                PD.setRace(p, all[m.race()]);
                p.sendSystemMessage(net.minecraft.network.chat.Component.literal("§6Has elegido ser §f" + all[m.race()].label + "§6. Que comience tu leyenda."));
                Passives.refresh(p);
                p.setHealth(p.getMaxHealth());
                sync(p);
            });
            c.get().setPacketHandled(true);
        });
        CH.registerMessage(id++, Action.class, (m, b) -> { b.writeInt(m.type()); b.writeInt(m.arg()); },
                b -> new Action(b.readInt(), b.readInt()), (m, c) -> {
            c.get().enqueueWork(() -> {
                ServerPlayer p = c.get().getSender();
                if (p == null || PD.race(p) == Race.NONE) return;
                switch (m.type()) {
                    case 0 -> Powers.use(p);
                    case 1 -> Powers.cycle(p, 1);
                    case 2 -> Powers.cycle(p, -1);
                    case 3 -> Powers.select(p, m.arg());
                    case 4 -> Absorb.renounceGraces(p);
                    case 5 -> Absorb.renounceCmds(p);
                    default -> { }
                }
            });
            c.get().setPacketHandled(true);
        });
    }

    private static ListTag strs(List<String> l) {
        ListTag t = new ListTag();
        for (String s : l) t.add(StringTag.valueOf(s));
        return t;
    }

    public static void sync(ServerPlayer p) {
        if (CH == null) return;
        CompoundTag t = new CompoundTag();
        t.putString("race", PD.race(p).name());
        t.putInt("dxp", PD.geti(p, "demonxp"));
        t.putInt("dlv", PD.demonLevel(p));
        t.putInt("frag", PD.geti(p, "fragments"));
        t.put("graces", strs(PD.list(p, "graces")));
        t.put("cmds", strs(PD.list(p, "cmds")));
        List<String> av = Powers.available(p);
        t.put("av", strs(av));
        int sel = av.isEmpty() ? 0 : Math.floorMod(PD.geti(p, "sel"), av.size());
        t.putInt("sel", sel);
        t.putInt("chaos", PD.list(p, "chaos").size());
        t.putInt("cd", av.isEmpty() ? 0 : Powers.cdLeft(p, av.get(sel)));
        CH.send(PacketDistributor.PLAYER.with(() -> p), new Sync(t));
    }

    public static void openRace(ServerPlayer p) {
        if (CH != null) CH.send(PacketDistributor.PLAYER.with(() -> p), new OpenRace());
    }
}
