package com.nanatsu.chaos;

import java.util.ArrayDeque;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.boss.wither.WitherBoss;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.monster.Evoker;
import net.minecraft.world.entity.monster.ElderGuardian;
import net.minecraft.world.entity.monster.Ravager;
import net.minecraft.world.entity.monster.WitherSkeleton;
import net.minecraft.world.entity.monster.piglin.PiglinBrute;
import net.minecraft.world.entity.monster.warden.Warden;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ProjectileWeaponItem;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;
import net.minecraftforge.event.LootTableLoadEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingEntityUseItemEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AdvancementEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerSleepInBedEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class Events {
    private static final ThreadLocal<Boolean> BARRIER = ThreadLocal.withInitial(() -> false);

    // ------------------------------------------------------------ jugador
    @SubscribeEvent
    public void onClone(PlayerEvent.Clone e) {
        CompoundTag old = e.getOriginal().getPersistentData();
        if (old.contains(PD.KEY)) {
            CompoundTag copy = old.getCompound(PD.KEY).copy();
            for (String k : new String[]{"nc_nebula", "nc_metal", "nc_aura", "nc_rebirth", "nc_unbroken", "nc_fly"}) copy.remove(k);
            e.getEntity().getPersistentData().put(PD.KEY, copy);
        }
    }

    @SubscribeEvent
    public void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) Net.sync(p);
    }

    @SubscribeEvent
    public void respawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            Passives.refresh(p);
            Net.sync(p);
        }
    }

    @SubscribeEvent
    public void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || !(e.player instanceof ServerPlayer p)) return;
        int t = p.tickCount;
        if (PD.race(p) == Race.NONE) {
            if (t % 100 == 40) Net.openRace(p);
            return;
        }
        CompoundTag d = PD.t(p);
        nebula(p, d);
        timers(p, d);
        if (t % 10 == 0) rules(p);
        if (t % 20 == 0) {
            Passives.refresh(p);
            ArrayDeque<double[]> q = Powers.HIST.computeIfAbsent(p.getUUID(), k -> new ArrayDeque<>());
            q.addLast(new double[]{p.getX(), p.getY(), p.getZ(), p.getHealth()});
            while (q.size() > 10) q.pollFirst();
            Net.sync(p);
            if (t % 100 == 0) claimExcalibur(p);
            if (t % 200 == 0) worldRolls(p);
        }
    }

    private void nebula(ServerPlayer p, CompoundTag d) {
        int n = d.getInt("nc_nebula");
        if (n <= 0) return;
        d.putInt("nc_nebula", n - 1);
        int phase = (160 - n) % 40;
        Vec3 c = p.position().add(0, 1, 0);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 5, 4, true, false));
        float dmg = 4 + 3 * PD.demonLevel(p);
        for (LivingEntity v : p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(22),
                x -> x != p && x.isAlive() && Powers.ok(p, x))) {
            if (phase < 26) {
                Vec3 to = c.subtract(v.position());
                Vec3 swirl = new Vec3(-to.z, 0, to.x).normalize().scale(0.5);
                v.setDeltaMovement(to.normalize().scale(0.9).add(swirl));
                v.hurtMarked = true;
                if (phase % 3 == 0) Powers.melee(p, v, dmg);
            } else if (phase == 26) {
                Vec3 away = v.position().subtract(c).normalize().scale(2.2);
                v.setDeltaMovement(away.x, 0.5, away.z);
                v.hurtMarked = true;
                Powers.melee(p, v, dmg * 3);
            }
        }
        Powers.sp(p, ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 30, 4, 0.5);
        if (phase % 4 == 0) Powers.sp(p, ParticleTypes.SWEEP_ATTACK, p.getX(), p.getY() + 1, p.getZ(), 4, 3, 0);
    }

    private void timers(ServerPlayer p, CompoundTag d) {
        int m = d.getInt("nc_metal");
        if (m > 0) {
            d.putInt("nc_metal", m - 1);
            if (m % 4 == 0) Powers.sp(p, ParticleTypes.CRIT, p.getX(), p.getY() + 1, p.getZ(), 6, 0.5, 0.05);
        }
        int a = d.getInt("nc_aura");
        if (a > 0) {
            d.putInt("nc_aura", a - 1);
            if (a % 5 == 0) {
                for (LivingEntity v : Powers.n(p, 7)) Powers.h(p, v, 12);
                Powers.sp(p, ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY() + 1, p.getZ(), 15, 3, 0.02);
            }
        }
        int r = d.getInt("nc_rebirth");
        if (r > 0) d.putInt("nc_rebirth", r - 1);
        int u = d.getInt("nc_unbroken");
        if (u > 0) d.putInt("nc_unbroken", u - 1);
        int f = d.getInt("nc_fly");
        if (f > 0) d.putInt("nc_fly", f - 1);
        if (!p.isCreative() && !p.isSpectator() && p.tickCount % 5 == 0) {
            boolean want = f > 0;
            if (p.getAbilities().mayfly != want) {
                p.getAbilities().mayfly = want;
                if (!want) {
                    p.getAbilities().flying = false;
                    p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 200, 0));
                }
                p.onUpdateAbilities();
            }
        }
    }

    private void rules(ServerPlayer p) {
        List<String> c = PD.list(p, "cmds");
        if (c.isEmpty()) return;
        if (c.contains("paciencia") && p.isSprinting()) p.setSprinting(false);
        if (c.contains("sinceridad") && p.isShiftKeyDown()) p.setShiftKeyDown(false);
        if (c.contains("voluntad")) {
            for (EquipmentSlot s : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                ItemStack st = p.getItemBySlot(s);
                if (!st.isEmpty()) {
                    p.setItemSlot(s, ItemStack.EMPTY);
                    if (!p.getInventory().add(st)) p.drop(st, false);
                    Powers.msg(p, "§cEl Mandamiento de la Voluntad te impide llevar armadura.");
                }
            }
        }
    }

    private void claimExcalibur(ServerPlayer p) {
        for (ItemStack s : p.getInventory().items) {
            if (s.getItem() instanceof Gifts.Excalibur) {
                CompoundTag t = s.getOrCreateTag();
                CathData cd = CathData.get(p.serverLevel().getServer());
                if (!cd.excalibur) {
                    cd.excalibur = true;
                    cd.setDirty();
                }
                if (!t.getBoolean("claimed")) {
                    t.putBoolean("claimed", true);
                    p.sendSystemMessage(Component.literal("§b§lExcalibur reconoce tu poder."));
                    Powers.grantRandom(p, 2, true);
                }
            }
        }
    }

    private void worldRolls(ServerPlayer p) {
        ServerLevel lv = p.serverLevel();
        RandomSource rnd = p.getRandom();
        CathData cd = CathData.get(lv.getServer());
        if (cd.state == 0 && lv.dimension() == Level.OVERWORLD && rnd.nextInt(90) == 0) {
            CathPalug c = Reg.CATH.get().create(lv);
            if (c != null) {
                double a = rnd.nextDouble() * Math.PI * 2, dist = 24 + rnd.nextInt(10);
                int x = (int) (p.getX() + Math.cos(a) * dist), z = (int) (p.getZ() + Math.sin(a) * dist);
                BlockPos g = lv.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, new BlockPos(x, 0, z));
                c.moveTo(g.getX() + 0.5, g.getY(), g.getZ() + 0.5, rnd.nextFloat() * 360f, 0f);
                lv.addFreshEntity(c);
                if (cd.excalibur) {
                    c.setBoss(true);
                    cd.state = 2;
                    lv.getServer().getPlayerList().broadcastSystemMessage(
                            Component.literal("§5§lUn rugido sacude el mundo... Cath Palug ha despertado."), false);
                } else {
                    cd.state = 1;
                }
                cd.setDirty();
            }
        }
        if (rnd.nextInt(8000) == 0) {
            String[] gs = Powers.GRACES;
            ItemStack g = new ItemStack(Reg.I.get(gs[rnd.nextInt(gs.length)]).get());
            double x = p.getX() + (rnd.nextDouble() - 0.5) * 80, z = p.getZ() + (rnd.nextDouble() - 0.5) * 80;
            ItemEntity ie = new ItemEntity(lv, x, p.getY() + 90, z, g);
            ie.setUnlimitedLifetime();
            ie.setGlowingTag(true);
            ie.setDeltaMovement(0, -0.3, 0);
            lv.addFreshEntity(ie);
            p.sendSystemMessage(Component.literal("§e§oUna luz sagrada cae del cielo cerca de ti..."));
        }
    }

    // ------------------------------------------------------------ reglas / chat / objetos
    @SubscribeEvent
    public void chat(ServerChatEvent e) {
        if (PD.has(e.getPlayer(), "cmds", "silencio")) {
            e.setCanceled(true);
            Powers.msg(e.getPlayer(), "§cEl Mandamiento del Silencio te impide hablar.");
        }
    }

    @SubscribeEvent
    public void toss(ItemTossEvent e) {
        if (e.getPlayer() instanceof ServerPlayer p && PD.has(p, "cmds", "verdad")) {
            e.setCanceled(true);
            Powers.msg(p, "§cEl Mandamiento de la Verdad te impide tirar objetos.");
        }
    }

    @SubscribeEvent
    public void sleep(PlayerSleepInBedEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && PD.has(p, "cmds", "reposo")) {
            e.setResult(Player.BedSleepingProblem.OTHER_PROBLEM);
            Powers.msg(p, "§cEl Mandamiento del Reposo te impide dormir.");
        }
    }

    @SubscribeEvent
    public void use(LivingEntityUseItemEvent.Start e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        Item i = e.getItem().getItem();
        if (i instanceof ProjectileWeaponItem && PD.has(p, "cmds", "fidelidad")) {
            e.setCanceled(true);
            Powers.msg(p, "§cEl Mandamiento de la Fidelidad te impide usar arcos.");
        }
        if (PD.has(p, "cmds", "pureza") && (i == Items.ROTTEN_FLESH || i == Items.BEEF || i == Items.PORKCHOP
                || i == Items.CHICKEN || i == Items.MUTTON || i == Items.RABBIT || i == Items.COD
                || i == Items.SALMON || i == Items.SPIDER_EYE)) {
            e.setCanceled(true);
            Powers.msg(p, "§cEl Mandamiento de la Pureza te impide comer eso.");
        }
    }

    // ------------------------------------------------------------ combate
    @SubscribeEvent
    public void attack(LivingAttackEvent e) {
        LivingEntity v = e.getEntity();
        DamageSource s = e.getSource();
        if (s.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return;
        if (v instanceof ServerPlayer p) {
            if (PD.race(p) == Race.NONE) {
                e.setCanceled(true);
                return;
            }
            CompoundTag d = PD.t(p);
            if (d.getInt("nc_nebula") > 0 || d.getInt("nc_metal") > 0) {
                e.setCanceled(true);
                return;
            }
            if (p.isUsingItem() && p.getUseItem().getItem() instanceof Treasures.Lostvayne) {
                CompoundTag t = p.getUseItem().getOrCreateTag();
                t.putDouble("stored", t.getDouble("stored") + e.getAmount());
                e.setCanceled(true);
                return;
            }
            if (PD.has(p, "graces", "gracia_viento")) {
                e.setCanceled(true);
                if (!BARRIER.get()) {
                    BARRIER.set(true);
                    try {
                        if (s.getEntity() instanceof LivingEntity at && at != p) {
                            at.invulnerableTime = 0;
                            at.hurt(p.damageSources().playerAttack(p), 10);
                        }
                        for (LivingEntity n : Powers.n(p, 4)) Powers.melee(p, n, 6);
                        Powers.sp(p, ParticleTypes.SWEEP_ATTACK, p.getX(), p.getY() + 1, p.getZ(), 6, 1.2, 0);
                    } finally {
                        BARRIER.set(false);
                    }
                }
                return;
            }
        }
        if (s.getEntity() instanceof ServerPlayer a && s.getDirectEntity() == a) {
            if (v instanceof Animal && PD.has(a, "cmds", "piedad")) {
                e.setCanceled(true);
                Powers.msg(a, "§cEl Mandamiento de la Piedad te impide danar a los inocentes.");
            } else if (v instanceof Player && PD.has(a, "cmds", "pacifismo")) {
                e.setCanceled(true);
                Powers.msg(a, "§cEl Mandamiento del Pacifismo te impide atacar jugadores.");
            }
        }
    }

    @SubscribeEvent
    public void hurt(LivingHurtEvent e) {
        LivingEntity v = e.getEntity();
        Entity a = e.getSource().getEntity();
        if (a instanceof ServerPlayer p && e.getSource().getDirectEntity() == p) {
            if (PD.t(p).getInt("nc_metal") > 0) e.setAmount(e.getAmount() * 2.5f);
            if (p.getMainHandItem().getItem() instanceof Treasures.Rhitta) {
                boolean sun = p.level().isDay() && p.level().canSeeSky(p.blockPosition());
                e.setAmount(e.getAmount() * (sun ? 3.5f : 1.3f));
            }
        }
        if (v instanceof ServerPlayer p && p.getHealth() - e.getAmount() <= 0) {
            CompoundTag d = PD.t(p);
            if (d.getInt("nc_rebirth") > 0) {
                e.setCanceled(true);
                p.setHealth(p.getMaxHealth());
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 100, 4));
                Powers.msg(p, "§5El Caos te hace renacer");
            } else if (d.getInt("nc_unbroken") > 0) {
                d.putInt("nc_unbroken", 0);
                e.setCanceled(true);
                p.setHealth(Math.max(4f, p.getMaxHealth() * 0.25f));
                Powers.msg(p, "§6Tu voluntad no se quiebra");
            } else if (Treasures.hasCourechouse(p) && Powers.ready(p, "infinity", 2400)) {
                e.setCanceled(true);
                Treasures.rewind(p);
                p.setHealth(Math.max(p.getMaxHealth() * 0.5f, 6f));
                Powers.msg(p, "§dInfinity: el tiempo retrocede");
            }
        }
    }

    @SubscribeEvent
    public void death(LivingDeathEvent e) {
        LivingEntity v = e.getEntity();
        if (e.getSource().getEntity() instanceof ServerPlayer p && v != p && PD.race(p) == Race.DEMONIO) {
            int xp = 0;
            if (v instanceof WitherBoss) xp = 300;
            else if (v instanceof EnderDragon) xp = 600;
            else if (v instanceof Warden) xp = 400;
            else if (v instanceof CathPalug c && c.isBoss()) xp = 2000;
            else if (v instanceof Evoker || v instanceof Ravager || v instanceof ElderGuardian
                    || v instanceof PiglinBrute || v instanceof WitherSkeleton) xp = 20;
            else if (v instanceof Enemy) xp = 2;
            if (xp > 0) Absorb.demonXp(p, xp);
        }
    }

    @SubscribeEvent
    public void drops(LivingDropsEvent e) {
        if (!(e.getSource().getEntity() instanceof ServerPlayer p) || PD.race(p) == Race.NONE) return;
        LivingEntity v = e.getEntity();
        int n = 0;
        if (v instanceof WitherBoss || v instanceof EnderDragon || v instanceof Warden || v instanceof ElderGuardian) {
            n = 6 + v.getRandom().nextInt(7);
        } else if (v instanceof Enemy && v.getRandom().nextFloat() < (PD.race(p) == Race.HUMANO ? 0.018f : 0.012f)) {
            n = 1;
        }
        if (n > 0) e.getDrops().add(new ItemEntity(v.level(), v.getX(), v.getY(), v.getZ(), new ItemStack(Reg.FRAGMENT.get(), n)));
    }

    @SubscribeEvent
    public void breakBlock(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p) || PD.race(p) == Race.NONE) return;
        if (e.getState().is(Tags.Blocks.ORES) && p.getRandom().nextFloat() < (PD.race(p) == Race.HUMANO ? 0.012f : 0.008f)) {
            Block.popResource((Level) e.getLevel(), e.getPos(), new ItemStack(Reg.FRAGMENT.get()));
        }
        if (e.getState().is(net.minecraft.world.level.block.Blocks.ANCIENT_DEBRIS)) Absorb.demonXp(p, 5);
    }

    @SubscribeEvent
    public void advancement(AdvancementEvent.AdvancementEarnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && e.getAdvancement().getDisplay() != null) Absorb.demonXp(p, 20);
    }

    @SubscribeEvent
    public void living(LivingEvent.LivingTickEvent e) {
        LivingEntity v = e.getEntity();
        if (v.level().isClientSide || !(v instanceof Mob m)) return;
        CompoundTag t = m.getPersistentData();
        if (t.contains("nc_life")) {
            int l = t.getInt("nc_life") - 1;
            t.putInt("nc_life", l);
            if (l <= 0) m.discard();
        }
        if (t.contains("nc_unfreeze")) {
            int l = t.getInt("nc_unfreeze") - 1;
            if (l <= 0) {
                t.remove("nc_unfreeze");
                m.setNoAi(false);
            } else {
                t.putInt("nc_unfreeze", l);
            }
        }
        if (t.contains("nc_charm")) {
            int l = t.getInt("nc_charm") - 1;
            if (l <= 0) {
                t.remove("nc_charm");
            } else {
                t.putInt("nc_charm", l);
                if (l % 10 == 0) {
                    LivingEntity best = null;
                    double bd = 1e9;
                    for (LivingEntity o : m.level().getEntitiesOfClass(LivingEntity.class, m.getBoundingBox().inflate(16),
                            x -> x != m && x.isAlive() && x instanceof Enemy)) {
                        double d = o.distanceToSqr(m);
                        if (d < bd) {
                            bd = d;
                            best = o;
                        }
                    }
                    m.setTarget(best);
                }
            }
        }
    }

    // ------------------------------------------------------------ botin en cofres
    @SubscribeEvent
    public void loot(LootTableLoadEvent e) {
        ResourceLocation n = e.getName();
        if (!n.getNamespace().equals("minecraft") || !n.getPath().startsWith("chests/")) return;
        for (String g : Powers.GRACES) add(e, g, 0.003f);
        for (String c : Powers.CMDS) add(e, "mandamiento_" + c, 0.002f);
        for (String t : new String[]{"lostvayne", "rhitta", "courechouse", "herrit", "aldan", "chastiefol", "gideon"}) add(e, t, 0.002f);
        for (String d : new String[]{"nebulosa_oscura", "metal_pesado", "danza_petalos", "juicio_divino", "voluntad_inquebrantable"}) add(e, "documento_" + d, 0.004f);
        add(e, "fragmento_caos", 0.15f);
        add(e, "excalibur", 0.0004f);
    }

    private static void add(LootTableLoadEvent e, String id, float chance) {
        e.getTable().addPool(LootPool.lootPool().setRolls(ConstantValue.exactly(1))
                .add(LootItem.lootTableItem(Reg.I.get(id).get()))
                .when(LootItemRandomChanceCondition.randomChance(chance)).build());
    }
}
