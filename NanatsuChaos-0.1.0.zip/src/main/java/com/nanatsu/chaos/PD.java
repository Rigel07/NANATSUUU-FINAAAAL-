package com.nanatsu.chaos;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;

/** Datos persistentes del jugador (se guardan en su NBT, sin capabilities). */
public final class PD {
    public static final String KEY = "nanatsuchaos";
    public static final int LV2 = 2000;
    public static final int LV3 = 12000;

    private PD() {}

    public static CompoundTag t(Player p) {
        CompoundTag root = p.getPersistentData();
        if (!root.contains(KEY, Tag.TAG_COMPOUND)) {
            root.put(KEY, new CompoundTag());
        }
        return root.getCompound(KEY);
    }

    public static Race race(Player p) {
        return Race.of(t(p).getString("race"));
    }

    public static void setRace(Player p, Race r) {
        t(p).putString("race", r.name());
    }

    public static List<String> list(Player p, String k) {
        ListTag l = t(p).getList(k, Tag.TAG_STRING);
        List<String> o = new ArrayList<>();
        for (int i = 0; i < l.size(); i++) {
            o.add(l.getString(i));
        }
        return o;
    }

    public static void setList(Player p, String k, List<String> v) {
        ListTag l = new ListTag();
        for (String s : v) {
            l.add(StringTag.valueOf(s));
        }
        t(p).put(k, l);
    }

    public static boolean has(Player p, String k, String v) {
        return list(p, k).contains(v);
    }

    public static boolean add(Player p, String k, String v) {
        List<String> l = list(p, k);
        if (l.contains(v)) {
            return false;
        }
        l.add(v);
        setList(p, k, l);
        return true;
    }

    public static int geti(Player p, String k) {
        return t(p).getInt(k);
    }

    public static void puti(Player p, String k, int v) {
        t(p).putInt(k, v);
    }

    public static int demonLevel(Player p) {
        int x = geti(p, "demonxp");
        return x >= LV3 ? 3 : (x >= LV2 ? 2 : 1);
    }
}
