package com.nanatsu.chaos.client;

import com.nanatsu.chaos.Net;
import com.nanatsu.chaos.PD;
import com.nanatsu.chaos.Powers;
import com.nanatsu.chaos.Race;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Menu de poderes (tecla J): habilidades, Gracias, Mandamientos, nivel de demonio y fragmentos. */
public class PowersScreen extends Screen {
    int page = 0;

    public PowersScreen() {
        super(Component.literal("Poderes"));
    }

    public void rebuild() { rebuildWidgets(); }

    @Override
    protected void init() {
        int per = 9;
        int x = width / 2 + 10;
        int y = 40;
        int start = page * per;
        for (int i = start; i < Math.min(ClientData.av.size(), start + per); i++) {
            final int idx = i;
            Powers.Ability a = Powers.ALL.get(ClientData.av.get(i));
            String nm = (i == ClientData.sel ? "» " : "") + (a != null ? a.name() : ClientData.av.get(i));
            addRenderableWidget(Button.builder(Component.literal(nm), b -> {
                ClientData.sel = idx;
                Net.CH.sendToServer(new Net.Action(3, idx));
                rebuildWidgets();
            }).bounds(x, y, 170, 18).build());
            y += 20;
        }
        int total = (ClientData.av.size() + per - 1) / per;
        if (page > 0) addRenderableWidget(Button.builder(Component.literal("<"), b -> { page--; rebuildWidgets(); })
                .bounds(x, y + 4, 40, 18).build());
        if (page + 1 < total) addRenderableWidget(Button.builder(Component.literal(">"), b -> { page++; rebuildWidgets(); })
                .bounds(x + 130, y + 4, 40, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Renunciar a Gracias"),
                b -> Net.CH.sendToServer(new Net.Action(4, 0))).bounds(20, height - 52, 140, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Renunciar a Mandamientos"),
                b -> Net.CH.sendToServer(new Net.Action(5, 0))).bounds(20, height - 28, 140, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.drawString(font, "§6§lPoderes", 20, 14, 0xFFFFFF);
        Race r = Race.of(ClientData.race);
        int y = 40;
        g.drawString(font, "Raza: §f" + r.label, 20, y, 0xFFD27A);
        y += 14;
        if (r == Race.DEMONIO) {
            int next = ClientData.dlv == 1 ? PD.LV2 : (ClientData.dlv == 2 ? PD.LV3 : -1);
            g.drawString(font, "Nivel de demonio: §c" + ClientData.dlv + (next > 0 ? " §7(" + ClientData.dxp + "/" + next + " XP)" : " §7(maximo)"), 20, y, 0xFFFFFF);
            y += 14;
        }
        g.drawString(font, "Fragmentos del Caos: §d" + ClientData.frag + " §7(sig. habilidad en " + (50 - ClientData.frag % 50) + ")", 20, y, 0xFFFFFF);
        y += 14;
        g.drawString(font, "Habilidades del Caos: §d" + ClientData.chaos + "/50", 20, y, 0xFFFFFF);
        y += 18;
        g.drawString(font, "§eGracias:", 20, y, 0xFFFFFF);
        y += 12;
        if (ClientData.graces.isEmpty()) {
            g.drawString(font, "§7ninguna", 28, y, 0xFFFFFF);
            y += 12;
        }
        for (String s : ClientData.graces) {
            g.drawString(font, "- " + Powers.GRACE_NAME.getOrDefault(s, s), 28, y, 0xFFFFFF);
            y += 12;
        }
        y += 6;
        g.drawString(font, "§cMandamientos (" + ClientData.cmds.size() + "/10):", 20, y, 0xFFFFFF);
        y += 12;
        if (ClientData.cmds.isEmpty()) {
            g.drawString(font, "§7ninguno", 28, y, 0xFFFFFF);
        }
        for (String s : ClientData.cmds) {
            g.drawString(font, "- " + Powers.CMD_NAME.getOrDefault(s, s), 28, y, 0xFFFFFF);
            y += 11;
        }
        g.drawString(font, "§7Elige la habilidad activa (tecla R para usarla, V para cambiar):", width / 2 + 10, 26, 0xFFFFFF);
        super.render(g, mx, my, pt);
    }
}
