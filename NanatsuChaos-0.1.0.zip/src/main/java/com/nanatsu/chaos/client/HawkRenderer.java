package com.nanatsu.chaos.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.nanatsu.chaos.Hawk;
import com.nanatsu.chaos.NanatsuChaos;
import net.minecraft.client.model.PigModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class HawkRenderer extends MobRenderer<Hawk, PigModel<Hawk>> {
    static final ResourceLocation TEX = new ResourceLocation(NanatsuChaos.MODID, "textures/entity/hawk.png");

    public HawkRenderer(EntityRendererProvider.Context c) {
        super(c, new PigModel<>(c.bakeLayer(ModelLayers.PIG)), 0.4f);
    }

    @Override
    public ResourceLocation getTextureLocation(Hawk e) { return TEX; }

    @Override
    protected void scale(Hawk e, PoseStack ps, float pt) { ps.scale(0.75f, 0.75f, 0.75f); }
}
