package com.nanatsu.chaos.client;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;

public class ClientHooks {
    public static void openRace() {
        Minecraft mc = Minecraft.getInstance();
        if (!(mc.screen instanceof RaceScreen)) mc.setScreen(new RaceScreen());
    }

    public static void sync(CompoundTag t) {
        ClientData.apply(t);
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen instanceof RaceScreen && !ClientData.race.equals("NONE")) mc.setScreen(null);
        if (mc.screen instanceof PowersScreen ps) ps.rebuild();
    }
}
