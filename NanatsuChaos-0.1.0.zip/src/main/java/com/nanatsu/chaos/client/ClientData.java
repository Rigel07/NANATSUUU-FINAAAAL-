package com.nanatsu.chaos.client;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

public class ClientData {
    public static String race = "NONE";
    public static int dxp, dlv = 1, frag, sel, chaos;
    public static long cdEnd = 0;
    public static List<String> graces = new ArrayList<>(), cmds = new ArrayList<>(), av = new ArrayList<>();

    static List<String> strs(CompoundTag t, String k) {
        List<String> o = new ArrayList<>();
        ListTag l = t.getList(k, Tag.TAG_STRING);
        for (int i = 0; i < l.size(); i++) o.add(l.getString(i));
        return o;
    }

    public static void apply(CompoundTag t) {
        race = t.getString("race");
        dxp = t.getInt("dxp");
        dlv = t.getInt("dlv");
        frag = t.getInt("frag");
        sel = t.getInt("sel");
        chaos = t.getInt("chaos");
        cdEnd = System.currentTimeMillis() + t.getInt("cd") * 1000L;
        graces = strs(t, "graces");
        cmds = strs(t, "cmds");
        av = strs(t, "av");
    }
}
