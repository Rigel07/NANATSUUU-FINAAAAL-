package com.nanatsu.chaos.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.nanatsu.chaos.CathPalug;
import com.nanatsu.chaos.NanatsuChaos;
import net.minecraft.client.model.OcelotModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class CathRenderer extends MobRenderer<CathPalug, OcelotModel<CathPalug>> {
    static final ResourceLocation KITTEN = new ResourceLocation(NanatsuChaos.MODID, "textures/entity/cath_kitten.png");
    static final ResourceLocation BOSS = new ResourceLocation(NanatsuChaos.MODID, "textures/entity/cath_boss.png");

    public CathRenderer(EntityRendererProvider.Context c) {
        super(c, new OcelotModel<>(c.bakeLayer(ModelLayers.OCELOT)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(CathPalug e) { return e.isBoss() ? BOSS : KITTEN; }

    @Override
    protected void scale(CathPalug e, PoseStack ps, float pt) {
        float s = e.isBoss() ? 4.0f : 1.15f;
        ps.scale(s, s, s);
    }
}
