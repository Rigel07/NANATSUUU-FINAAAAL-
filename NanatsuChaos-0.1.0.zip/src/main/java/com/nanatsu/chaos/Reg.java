package com.nanatsu.chaos;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class Reg {
    private Reg() {}

    public static final String ID = NanatsuChaos.MODID;
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ID);
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);

    public static final Map<String, RegistryObject<Item>> I = new LinkedHashMap<>();
    public static final Map<String, RegistryObject<Block>> B = new LinkedHashMap<>();

    static RegistryObject<Item> item(String id, Supplier<Item> s) {
        RegistryObject<Item> r = ITEMS.register(id, s);
        I.put(id, r);
        return r;
    }

    static void block(String id, StatueBlock.Kind k, String data, int light) {
        RegistryObject<Block> r = BLOCKS.register(id, () -> new StatueBlock(
                BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(3.0f, 6.0f).noOcclusion()
                        .lightLevel(s -> light), k, data));
        B.put(id, r);
        ITEMS.register(id, () -> new BlockItem(r.get(), new Item.Properties()));
    }

    // ---- entidades
    public static final RegistryObject<EntityType<Hawk>> HAWK = ENTITIES.register("hawk", () ->
            EntityType.Builder.<Hawk>of(Hawk::new, MobCategory.CREATURE).sized(0.5f, 0.6f).clientTrackingRange(8).build("hawk"));
    public static final RegistryObject<EntityType<CathPalug>> CATH = ENTITIES.register("cath_palug", () ->
            EntityType.Builder.<CathPalug>of(CathPalug::new, MobCategory.CREATURE).sized(0.6f, 0.7f).clientTrackingRange(10).build("cath_palug"));
    public static final RegistryObject<EntityType<Fairy>> FAIRY = ENTITIES.register("fairy", () ->
            EntityType.Builder.<Fairy>of(Fairy::new, MobCategory.CREATURE).sized(0.4f, 0.7f).clientTrackingRange(8).build("fairy"));
    public static final RegistryObject<EntityType<HolyKnight>> KNIGHT = ENTITIES.register("holy_knight", () ->
            EntityType.Builder.<HolyKnight>of(HolyKnight::new, MobCategory.CREATURE).sized(0.6f, 1.95f).clientTrackingRange(8).build("holy_knight"));
    public static final RegistryObject<EntityType<Escanor>> ESCANOR = ENTITIES.register("escanor", () ->
            EntityType.Builder.<Escanor>of(Escanor::new, MobCategory.CREATURE).sized(0.9f, 2.6f).clientTrackingRange(8).build("escanor"));
    public static final RegistryObject<EntityType<IllusionClone>> CLONE = ENTITIES.register("illusion_clone", () ->
            EntityType.Builder.<IllusionClone>of(IllusionClone::new, MobCategory.CREATURE).sized(0.6f, 1.8f).clientTrackingRange(8).build("illusion_clone"));

    // ---- items sueltos
    public static final RegistryObject<Item> FRAGMENT = item("fragmento_caos", Gifts.Fragment::new);
    public static final RegistryObject<Item> EXCALIBUR = item("excalibur", Gifts.Excalibur::new);

    static {
        for (String g : Powers.GRACES) item(g, () -> new Gifts.Grace(g));
        for (String c : Powers.CMDS) item("mandamiento_" + c, () -> new Gifts.Commandment(c));
        item("documento_nebulosa_oscura", () -> new Gifts.Doc("nebulosa_oscura", Race.DEMONIO));
        item("documento_metal_pesado", () -> new Gifts.Doc("metal_pesado", Race.GIGANTE));
        item("documento_danza_petalos", () -> new Gifts.Doc("danza_petalos", Race.HADA));
        item("documento_juicio_divino", () -> new Gifts.Doc("juicio_divino", Race.DIOSA));
        item("documento_voluntad_inquebrantable", () -> new Gifts.Doc("voluntad_inquebrantable", Race.HUMANO));
        item("lostvayne", Treasures.Lostvayne::new);
        item("rhitta", Treasures.Rhitta::new);
        item("courechouse", Treasures.Courechouse::new);
        item("herrit", Treasures.Herrit::new);
        item("aldan", Treasures.Aldan::new);
        item("chastiefol", Treasures.Chastiefol::new);
        item("gideon", Treasures.Gideon::new);
        item("hawk_spawn_egg", () -> new ForgeSpawnEggItem(HAWK, 0xF2EDE0, 0x2A2A2A, new Item.Properties()));
        item("fairy_spawn_egg", () -> new ForgeSpawnEggItem(FAIRY, 0x7BE0A5, 0xFFF59A, new Item.Properties()));
        item("holy_knight_spawn_egg", () -> new ForgeSpawnEggItem(KNIGHT, 0xC9CED6, 0x2D4FA8, new Item.Properties()));
        item("escanor_spawn_egg", () -> new ForgeSpawnEggItem(ESCANOR, 0xE8A33D, 0x7A3B12, new Item.Properties()));
        for (String s : new String[]{"meliodas", "diane", "ban", "king", "gowther", "merlin", "escanor", "hawk"}) {
            block("estatua_" + s, StatueBlock.Kind.SIN, s, 0);
        }
        for (String s : new String[]{"sol", "brillo", "oceano", "viento"}) {
            block("arcangel_" + s, StatueBlock.Kind.ARCHANGEL, s, 12);
        }
        block("piedra_excalibur", StatueBlock.Kind.EXCALIBUR, "excalibur", 8);
        FEATURES.register("sin_statues", Worldgen.SinStatues::new);
        FEATURES.register("archangel", Worldgen.Archangel::new);
        FEATURES.register("excalibur_stone", Worldgen.ExcaliburStone::new);
        FEATURES.register("liones", Worldgen.Liones::new);
        FEATURES.register("fairy_forest", Worldgen.FairyForest::new);
        FEATURES.register("treasure_shrine", Worldgen.TreasureShrine::new);
        TABS.register("main", () -> CreativeModeTab.builder()
                .title(Component.literal("Nanatsu Chaos"))
                .icon(() -> new ItemStack(EXCALIBUR.get()))
                .displayItems((params, out) -> {
                    for (RegistryObject<Item> r : ITEMS.getEntries()) out.accept(r.get());
                }).build());
    }

    public static void init(IEventBus bus) {
        ITEMS.register(bus);
        BLOCKS.register(bus);
        ENTITIES.register(bus);
        FEATURES.register(bus);
        TABS.register(bus);
    }

    public static void attributes(EntityAttributeCreationEvent e) {
        e.put(HAWK.get(), Hawk.attrs().build());
        e.put(CATH.get(), CathPalug.attrs().build());
        e.put(FAIRY.get(), Fairy.attrs().build());
        e.put(KNIGHT.get(), HolyKnight.attrs().build());
        e.put(ESCANOR.get(), Escanor.attrs().build());
        e.put(CLONE.get(), IllusionClone.attrs().build());
    }

    public static void spawns(SpawnPlacementRegisterEvent e) {
        e.register(HAWK.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                Animal::checkAnimalSpawnRules, SpawnPlacementRegisterEvent.Operation.OR);
    }
}
