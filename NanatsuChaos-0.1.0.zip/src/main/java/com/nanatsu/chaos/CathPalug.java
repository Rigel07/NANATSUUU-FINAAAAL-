package com.nanatsu.chaos;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Vex;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Cath Palug: gatito rechoncho y companero... hasta que aparece Excalibur. */
public class CathPalug extends TamableAnimal {
    static final EntityDataAccessor<Boolean> BOSS = SynchedEntityData.defineId(CathPalug.class, EntityDataSerializers.BOOLEAN);
    final ServerBossEvent bar = new ServerBossEvent(Component.literal("Cath Palug, la Bestia del Caos"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);
    final Set<UUID> hitters = new HashSet<>();
    int cd = 0;

    public CathPalug(EntityType<? extends TamableAnimal> t, Level l) {
        super(t, l);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attrs() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 10).add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.ATTACK_DAMAGE, 2).add(Attributes.FOLLOW_RANGE, 32);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(BOSS, false);
    }

    public boolean isBoss() { return this.entityData.get(BOSS); }

    public void setBoss(boolean b) {
        this.entityData.set(BOSS, b);
        if (b) {
            setTame(false);
            setOwnerUUID(null);
            setOrderedToSit(false);
            getAttribute(Attributes.MAX_HEALTH).setBaseValue(1500);
            getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(28);
            getAttribute(Attributes.ARMOR).setBaseValue(30);
            getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.36);
            getAttribute(Attributes.FOLLOW_RANGE).setBaseValue(64);
            getAttribute(Attributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0);
            setHealth(1500f);
        }
        refreshDimensions();
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (BOSS.equals(key)) refreshDimensions();
        super.onSyncedDataUpdated(key);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        EntityDimensions d = super.getDimensions(pose);
        return isBoss() ? d.scale(4f) : d;
    }

    public static boolean allowed(DamageSource s) {
        if (s.is(Powers.CHAOS)) return true;
        return s.getDirectEntity() instanceof Player p && s.getEntity() == p && p.getMainHandItem().getItem() instanceof Gifts.Excalibur;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(3, new MeleeAttackGoal(this, 1.3, true) {
            @Override public boolean canUse() { return CathPalug.this.isBoss() && super.canUse(); }
            @Override public boolean canContinueToUse() { return CathPalug.this.isBoss() && super.canContinueToUse(); }
        });
        this.goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.1, 8, 2, false) {
            @Override public boolean canUse() { return !CathPalug.this.isBoss() && super.canUse(); }
        });
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<Player>(this, Player.class, true) {
            @Override public boolean canUse() { return CathPalug.this.isBoss() && super.canUse(); }
        });
    }

    @Override
    public boolean hurt(DamageSource s, float a) {
        if (isBoss()) {
            if (!allowed(s)) return false;
            if (s.getEntity() instanceof Player p) hitters.add(p.getUUID());
            return super.hurt(s, a);
        }
        if (s.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(s, a);
        return false;
    }

    @Override
    public void die(DamageSource s) {
        super.die(s);
        if (level().isClientSide) return;
        ServerLevel lv = (ServerLevel) level();
        CathData d = CathData.get(lv.getServer());
        if (isBoss()) {
            d.state = 3;
            d.setDirty();
            for (UUID u : hitters) {
                ServerPlayer sp = lv.getServer().getPlayerList().getPlayer(u);
                if (sp != null) {
                    sp.sendSystemMessage(Component.literal("§5Absorbes el Caos de Cath Palug..."));
                    Powers.grantRandom(sp, 3, true);
                }
            }
            bar.removeAllPlayers();
        } else {
            d.state = 0;
            d.setDirty();
        }
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        ServerLevel lv = (ServerLevel) level();
        bar.setVisible(isBoss());
        if (!isBoss()) {
            if (tickCount % 40 == 0) {
                CathData d = CathData.get(lv.getServer());
                if (d.excalibur) {
                    setBoss(true);
                    d.state = 2;
                    d.setDirty();
                    lv.getServer().getPlayerList().broadcastSystemMessage(
                            Component.literal("§5§lUn rugido sacude el mundo... Cath Palug ha despertado."), false);
                }
            }
            return;
        }
        bar.setProgress(getHealth() / getMaxHealth());
        LivingEntity t = getTarget();
        if (t == null || ++cd < 80) return;
        cd = 0;
        switch (getRandom().nextInt(4)) {
            case 0 -> slam(lv);
            case 1 -> {
                Vec3 v = t.position().subtract(position()).normalize().scale(1.6);
                setDeltaMovement(v.x, 0.9, v.z);
            }
            case 2 -> {
                for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(24))) {
                    p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 100, 0));
                    p.addEffect(new MobEffectInstance(MobEffects.WITHER, 120, 1));
                    p.hurt(damageSources().mobAttack(this), 12);
                }
                lv.sendParticles(ParticleTypes.SONIC_BOOM, getX(), getY() + 2, getZ(), 1, 0, 0, 0, 0);
            }
            default -> {
                for (int i = 0; i < 3; i++) {
                    Vex v = EntityType.VEX.create(level());
                    if (v == null) continue;
                    v.moveTo(getX() + getRandom().nextInt(5) - 2, getY() + 1, getZ() + getRandom().nextInt(5) - 2);
                    v.setOwner(this);
                    v.setBoundOrigin(blockPosition());
                    v.setLimitedLife(600);
                    lv.addFreshEntity(v);
                }
            }
        }
    }

    private void slam(ServerLevel lv) {
        for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(10))) {
            p.hurt(damageSources().mobAttack(this), 25);
            Vec3 v = p.position().subtract(position()).normalize().scale(1.6);
            p.setDeltaMovement(v.x, 0.7, v.z);
            p.hurtMarked = true;
        }
        lv.sendParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY(), getZ(), 2, 2, 0.5, 2, 0);
        lv.playSound(null, blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 2f, 0.6f);
    }

    @Override
    public InteractionResult mobInteract(Player p, InteractionHand h) {
        ItemStack s = p.getItemInHand(h);
        if (isBoss()) return InteractionResult.PASS;
        if (!isTame() && s.is(ItemTags.FISHES)) {
            if (!level().isClientSide) {
                if (!p.getAbilities().instabuild) s.shrink(1);
                if (getRandom().nextInt(3) == 0) {
                    tame(p);
                    level().broadcastEntityEvent(this, (byte) 7);
                } else {
                    level().broadcastEntityEvent(this, (byte) 6);
                }
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (isTame() && isOwnedBy(p) && s.isEmpty()) {
            if (!level().isClientSide) setOrderedToSit(!isOrderedToSit());
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bar.addPlayer(p); }
    @Override public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bar.removePlayer(p); }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public AgeableMob getBreedOffspring(ServerLevel l, AgeableMob o) { return null; }
    @Override protected SoundEvent getAmbientSound() { return isBoss() ? SoundEvents.CAT_HISS : SoundEvents.CAT_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.CAT_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.CAT_DEATH; }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putBoolean("Boss", isBoss());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        if (t.getBoolean("Boss")) {
            this.entityData.set(BOSS, true);
            refreshDimensions();
        }
    }
}
