package com.nanatsu.chaos;

import java.util.*;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.projectile.Arrow;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.entity.projectile.SmallFireball;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Catalogo de habilidades activas y utilidades de combate. */
public final class Powers {
    public interface Exec { void run(ServerPlayer p); }

    public record Ability(String id, String name, int level, int cd, Exec fn) {}

    public static final Map<String, Ability> ALL = new LinkedHashMap<>();
    public static final ResourceKey<DamageType> CHAOS =
            ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation(NanatsuChaos.MODID, "chaos"));

    public static final String[] GRACES = {"gracia_sol", "gracia_brillo", "gracia_oceano", "gracia_viento"};
    public static final Map<String, String> GRACE_NAME = new LinkedHashMap<>();
    public static final String[] CMDS = {"verdad", "pureza", "sinceridad", "piedad", "pacifismo",
            "reposo", "fidelidad", "silencio", "voluntad", "paciencia"};
    public static final Map<String, String> CMD_NAME = new LinkedHashMap<>();
    public static final Map<String, String> CMD_RULE = new LinkedHashMap<>();
    public static final Map<String, Map<String, Long>> CD = new HashMap<>();
    public static final Map<UUID, ArrayDeque<double[]>> HIST = new HashMap<>();

    static {
        GRACE_NAME.put("gracia_sol", "Gracia del Sol");
        GRACE_NAME.put("gracia_brillo", "Gracia del Brillo");
        GRACE_NAME.put("gracia_oceano", "Gracia del Oceano");
        GRACE_NAME.put("gracia_viento", "Gracia del Viento");
        String[][] c = {
                {"verdad", "Mandamiento de la Verdad", "Regla: no puedes tirar objetos al suelo."},
                {"pureza", "Mandamiento de la Pureza", "Regla: no puedes comer carne cruda ni podrida."},
                {"sinceridad", "Mandamiento de la Sinceridad", "Regla: no puedes agacharte."},
                {"piedad", "Mandamiento de la Piedad", "Regla: no puedes atacar animales pasivos."},
                {"pacifismo", "Mandamiento del Pacifismo", "Regla: no puedes atacar a otros jugadores."},
                {"reposo", "Mandamiento del Reposo", "Regla: no puedes dormir en una cama."},
                {"fidelidad", "Mandamiento de la Fidelidad", "Regla: no puedes usar arcos ni ballestas."},
                {"silencio", "Mandamiento del Silencio", "Regla: no puedes escribir en el chat."},
                {"voluntad", "Mandamiento de la Voluntad", "Regla: no puedes llevar armadura."},
                {"paciencia", "Mandamiento de la Paciencia", "Regla: no puedes correr."}};
        for (String[] s : c) {
            CMD_NAME.put(s[0], s[1]);
            CMD_RULE.put(s[0], s[2]);
        }
        init();
    }

    private Powers() {}

    // ------------------------------------------------------------------ utilidades
    static void reg(String id, String name, int level, int cdSec, Exec f) {
        ALL.put(id, new Ability(id, name, level, cdSec * 20, f));
    }

    public static void msg(ServerPlayer p, String s) {
        p.displayClientMessage(Component.literal(s), true);
    }

    public static boolean ok(ServerPlayer p, LivingEntity e) {
        if (e instanceof Player) return false;
        if (e instanceof TamableAnimal t && t.isOwnedBy(p)) return false;
        if (e instanceof CathPalug c) return c.isBoss();
        return e instanceof Enemy || (e instanceof Mob m && m.getTarget() == p);
    }

    public static List<LivingEntity> n(ServerPlayer p, double r) {
        return p.level().getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(r),
                e -> e != p && e.isAlive() && ok(p, e));
    }

    public static List<LivingEntity> at(ServerPlayer p, Vec3 c, double r) {
        return p.level().getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(r),
                e -> e != p && e.isAlive() && ok(p, e));
    }

    static LivingEntity nearest(ServerPlayer p, double r) {
        LivingEntity best = null;
        double bd = 1e9;
        for (LivingEntity e : n(p, r)) {
            double d = e.distanceToSqr(p);
            if (d < bd) {
                bd = d;
                best = e;
            }
        }
        return best;
    }

    static double rnd(ServerPlayer p, double r) {
        return (p.getRandom().nextDouble() - 0.5) * 2 * r;
    }

    static void sp(ServerPlayer p, ParticleOptions pt, double x, double y, double z, int n, double spread, double speed) {
        p.serverLevel().sendParticles(pt, x, y, z, n, spread, spread, spread, speed);
    }

    static void fx(LivingEntity e, MobEffect m, int sec, int amp) {
        e.addEffect(new MobEffectInstance(m, sec * 20, amp));
    }

    /** dano del Caos: el unico (junto a Excalibur) que afecta a Cath Palug jefe. */
    public static void h(ServerPlayer p, LivingEntity e, float a) {
        e.invulnerableTime = 0;
        e.hurt(p.damageSources().source(CHAOS, p), a);
    }

    public static void melee(ServerPlayer p, LivingEntity e, float a) {
        e.invulnerableTime = 0;
        e.hurt(p.damageSources().playerAttack(p), a);
    }

    static void push(ServerPlayer p, LivingEntity e, double s, double up) {
        Vec3 v = e.position().subtract(p.position());
        v = new Vec3(v.x, 0, v.z).normalize().scale(s);
        e.setDeltaMovement(v.x, up, v.z);
        e.hurtMarked = true;
    }

    static void pull(Vec3 c, LivingEntity e, double s) {
        Vec3 v = c.subtract(e.position()).normalize().scale(s);
        e.setDeltaMovement(v);
        e.hurtMarked = true;
    }

    public static Vec3 aim(ServerPlayer p, double range) {
        Vec3 s = p.getEyePosition();
        Vec3 e = s.add(p.getLookAngle().scale(range));
        BlockHitResult r = p.level().clip(new ClipContext(s, e, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return r.getType() == HitResult.Type.MISS ? e : r.getLocation();
    }

    static Vec3 flat(ServerPlayer p) {
        Vec3 l = p.getLookAngle();
        return new Vec3(l.x, 0, l.z).normalize();
    }

    /** Rayo con dano. chaos=true usa dano del Caos, si no dano de jugador. */
    public static int ray(ServerPlayer p, Vec3 dir, double range, double w, float dmg, ParticleOptions pt, boolean fire, boolean chaos) {
        Vec3 s = p.getEyePosition();
        Set<LivingEntity> hit = new HashSet<>();
        for (double d = 1; d <= range; d += 1) {
            Vec3 c = s.add(dir.scale(d));
            BlockPos bp = BlockPos.containing(c);
            if (!p.level().getBlockState(bp).getCollisionShape(p.level(), bp).isEmpty()) break;
            sp(p, pt, c.x, c.y, c.z, 2, 0.1, 0);
            for (LivingEntity e : p.level().getEntitiesOfClass(LivingEntity.class, new AABB(c, c).inflate(w),
                    x -> x != p && x.isAlive() && ok(p, x))) {
                if (hit.add(e)) {
                    if (chaos) h(p, e, dmg); else melee(p, e, dmg);
                    if (fire) e.setSecondsOnFire(6);
                }
            }
        }
        return hit.size();
    }

    static void bolt(ServerPlayer p, Vec3 pos) {
        LightningBolt b = EntityType.LIGHTNING_BOLT.create(p.level());
        if (b != null) {
            b.moveTo(pos);
            b.setVisualOnly(true);
            p.level().addFreshEntity(b);
        }
    }

    static void fire(ServerPlayer p, double x, double y, double z, int power) {
        LargeFireball f = new LargeFireball(p.level(), p, 0, -1, 0, power);
        f.setPos(x, y, z);
        f.setDeltaMovement(0, -1.0, 0);
        p.level().addFreshEntity(f);
    }

    static void cleanse(ServerPlayer p) {
        List<MobEffect> bad = new ArrayList<>();
        for (MobEffectInstance i : p.getActiveEffects()) {
            if (i.getEffect().getCategory() == MobEffectCategory.HARMFUL) bad.add(i.getEffect());
        }
        for (MobEffect m : bad) p.removeEffect(m);
    }

    static void boom(ServerPlayer p) {
        p.level().playSound(null, p.blockPosition(), SoundEvents.GENERIC_EXPLODE, SoundSource.PLAYERS, 1.0f, 1.0f);
    }

    // ------------------------------------------------------------------ uso y cooldowns
    public static boolean ready(ServerPlayer p, String key, int ticks) {
        long now = p.level().getGameTime();
        Map<String, Long> m = CD.computeIfAbsent(p.getUUID().toString(), k -> new HashMap<>());
        long end = m.getOrDefault(key, 0L);
        if (now < end) {
            msg(p, "En enfriamiento: " + ((end - now) / 20 + 1) + "s");
            return false;
        }
        m.put(key, now + ticks);
        return true;
    }

    public static int cdLeft(ServerPlayer p, String key) {
        long now = p.level().getGameTime();
        Map<String, Long> m = CD.get(p.getUUID().toString());
        if (m == null) return 0;
        return (int) Math.max(0, (m.getOrDefault(key, 0L) - now) / 20 + 1);
    }

    public static List<String> available(ServerPlayer p) {
        List<String> l = new ArrayList<>();
        switch (PD.race(p)) {
            case HUMANO -> l.add("voluntad_humana");
            case GIGANTE -> l.add("pisoton");
            case DEMONIO -> l.add("llama_oscura");
            case HADA -> l.add("polvo_hada");
            case DIOSA -> l.add("bendicion_divina");
            default -> { }
        }
        l.addAll(PD.list(p, "docs"));
        l.addAll(PD.list(p, "graces"));
        if (PD.list(p, "cmds").size() >= 10) l.add("rey_demonio");
        l.addAll(PD.list(p, "chaos"));
        return l;
    }

    public static Ability selected(ServerPlayer p) {
        List<String> av = available(p);
        if (av.isEmpty()) return null;
        return ALL.get(av.get(Math.floorMod(PD.geti(p, "sel"), av.size())));
    }

    public static void use(ServerPlayer p) {
        Ability a = selected(p);
        if (a == null) {
            msg(p, "Aun no tienes habilidades.");
            return;
        }
        if (!ready(p, a.id(), a.cd())) return;
        a.fn().run(p);
        msg(p, "§d" + a.name());
        Net.sync(p);
    }

    public static void cycle(ServerPlayer p, int dir) {
        int size = available(p).size();
        if (size == 0) return;
        PD.puti(p, "sel", Math.floorMod(PD.geti(p, "sel") + dir, size));
        Ability a = selected(p);
        if (a != null) msg(p, "Habilidad: " + a.name());
        Net.sync(p);
    }

    public static void select(ServerPlayer p, int i) {
        if (i >= 0 && i < available(p).size()) PD.puti(p, "sel", i);
        Net.sync(p);
    }

    public static void grantRandom(ServerPlayer p, int level, boolean announce) {
        List<String> owned = PD.list(p, "chaos");
        if (owned.size() >= 50) {
            msg(p, "Has alcanzado el limite de 50 habilidades del Caos.");
            return;
        }
        List<String> pool = new ArrayList<>();
        for (Ability a : ALL.values()) {
            if (a.level() == level && !owned.contains(a.id())) pool.add(a.id());
        }
        if (pool.isEmpty()) return;
        String id = pool.get(p.getRandom().nextInt(pool.size()));
        PD.add(p, "chaos", id);
        if (announce) {
            p.sendSystemMessage(Component.literal("§5§l¡El Caos te reconoce! §dNueva habilidad (nivel " + level + "): §f" + ALL.get(id).name()));
            p.level().playSound(null, p.blockPosition(), SoundEvents.END_PORTAL_SPAWN, SoundSource.PLAYERS, 0.6f, 1.4f);
        }
        Net.sync(p);
    }

    // ------------------------------------------------------------------ catalogo
    static void c1(String id, String name, int cd, Exec f) { reg(id, name, 1, cd, f); }
    static void c2(String id, String name, int cd, Exec f) { reg(id, name, 2, cd, f); }
    static void c3(String id, String name, int cd, Exec f) { reg(id, name, 3, cd, f); }

    private static void init() {
        // ---------------- razas
        reg("voluntad_humana", "Voluntad Humana", 0, 90, p -> {
            p.heal(20);
            fx(p, MobEffects.DAMAGE_RESISTANCE, 10, 2);
            fx(p, MobEffects.REGENERATION, 8, 2);
            cleanse(p);
            sp(p, ParticleTypes.HAPPY_VILLAGER, p.getX(), p.getY() + 1, p.getZ(), 40, 0.6, 0.1);
        });
        reg("pisoton", "Pisoton Gigante", 0, 20, p -> {
            for (LivingEntity e : n(p, 12)) {
                melee(p, e, 22);
                push(p, e, 1.5, 0.6);
            }
            sp(p, ParticleTypes.EXPLOSION, p.getX(), p.getY() + 0.2, p.getZ(), 12, 3, 0);
            boom(p);
        });
        reg("llama_oscura", "Llama Oscura", 0, 8, p ->
                ray(p, p.getLookAngle(), 26, 1.5, 16 + 10 * PD.demonLevel(p), ParticleTypes.SOUL_FIRE_FLAME, true, false));
        reg("polvo_hada", "Polvo de Hada", 0, 45, p -> {
            PD.puti(p, "nc_fly", 400);
            p.setDeltaMovement(p.getDeltaMovement().add(0, 0.6, 0));
            p.hurtMarked = true;
            sp(p, ParticleTypes.END_ROD, p.getX(), p.getY() + 1, p.getZ(), 40, 0.6, 0.05);
            msg(p, "Puedes volar durante 20 segundos");
        });
        reg("bendicion_divina", "Bendicion Divina", 0, 40, p -> {
            p.heal(30);
            cleanse(p);
            for (Player o : p.level().getEntitiesOfClass(Player.class, p.getBoundingBox().inflate(12))) {
                o.heal(20);
                fx(o, MobEffects.REGENERATION, 8, 2);
            }
            sp(p, ParticleTypes.TOTEM_OF_UNDYING, p.getX(), p.getY() + 1, p.getZ(), 60, 1.2, 0.2);
        });
        // ---------------- documentos perdidos
        reg("nebulosa_oscura", "Nebulosa Oscura", 0, 45, p -> PD.puti(p, "nc_nebula", 160));
        reg("metal_pesado", "Metal Pesado", 0, 60, p -> PD.puti(p, "nc_metal", 400));
        reg("danza_petalos", "Danza de Petalos", 0, 18, p -> {
            for (LivingEntity e : n(p, 10)) {
                melee(p, e, 14);
                fx(e, MobEffects.MOVEMENT_SLOWDOWN, 4, 1);
            }
            p.heal(8);
            sp(p, ParticleTypes.CHERRY_LEAVES, p.getX(), p.getY() + 1.5, p.getZ(), 120, 3, 0.05);
        });
        reg("juicio_divino", "Juicio Divino", 0, 30, p -> {
            Vec3 t = aim(p, 40);
            for (int i = 0; i < 6; i++) bolt(p, t.add(rnd(p, 4), 0, rnd(p, 4)));
            for (LivingEntity e : at(p, t, 6)) melee(p, e, 45);
        });
        reg("voluntad_inquebrantable", "Voluntad Inquebrantable", 0, 120, p -> {
            PD.puti(p, "nc_unbroken", 1200);
            fx(p, MobEffects.ABSORPTION, 30, 2);
            msg(p, "Sobreviviras al proximo golpe mortal (60s)");
        });
        // ---------------- Gracias
        reg("gracia_sol", "Sol Cruel", 0, 30, p -> {
            float d = p.level().isDay() ? 260 : 120;
            for (LivingEntity e : n(p, 28)) {
                melee(p, e, d);
                e.setSecondsOnFire(15);
            }
            sp(p, ParticleTypes.FLAME, p.getX(), p.getY() + 2, p.getZ(), 300, 8, 0.2);
            boom(p);
        });
        reg("gracia_brillo", "Lanzas de Luz", 0, 10, p -> {
            for (int i = -2; i <= 2; i++) {
                ray(p, p.getLookAngle().yRot((float) Math.toRadians(i * 8)), 40, 1.2, 45, ParticleTypes.END_ROD, false, false);
            }
            for (LivingEntity e : n(p, 14)) fx(e, MobEffects.GLOWING, 8, 0);
        });
        reg("gracia_oceano", "Marea Colosal", 0, 14, p -> {
            for (LivingEntity e : n(p, 22)) {
                melee(p, e, 50);
                push(p, e, 2.5, 0.5);
                fx(e, MobEffects.MOVEMENT_SLOWDOWN, 5, 2);
            }
            fx(p, MobEffects.DOLPHINS_GRACE, 10, 1);
            sp(p, ParticleTypes.SPLASH, p.getX(), p.getY() + 1, p.getZ(), 400, 8, 0.4);
        });
        reg("gracia_viento", "Tornado Cortante", 0, 12, p -> {
            for (LivingEntity e : n(p, 18)) {
                e.setDeltaMovement(0, 1.8, 0);
                e.hurtMarked = true;
                melee(p, e, 35);
            }
            fx(p, MobEffects.MOVEMENT_SPEED, 6, 3);
            sp(p, ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 200, 5, 0.3);
        });
        reg("rey_demonio", "Aniquilacion del Rey Demonio", 0, 20, p -> {
            for (LivingEntity e : n(p, 35)) {
                melee(p, e, 150);
                fx(e, MobEffects.WITHER, 8, 2);
                e.setSecondsOnFire(10);
            }
            sp(p, ParticleTypes.SOUL_FIRE_FLAME, p.getX(), p.getY() + 1, p.getZ(), 400, 10, 0.3);
            boom(p);
        });

        // ---------------- Caos nivel 1
        c1("salto_caos", "Salto del Caos", 6, p -> {
            Vec3 d = p.getLookAngle().scale(2.4);
            p.setDeltaMovement(d.x, Math.max(d.y, 0.4) + 0.2, d.z);
            p.hurtMarked = true;
            fx(p, MobEffects.SLOW_FALLING, 4, 0);
            sp(p, ParticleTypes.PORTAL, p.getX(), p.getY() + 1, p.getZ(), 60, 0.5, 0.5);
        });
        c1("aliento_gelido", "Aliento Gelido", 12, p -> {
            for (LivingEntity e : n(p, 9)) {
                fx(e, MobEffects.MOVEMENT_SLOWDOWN, 6, 2);
                e.setTicksFrozen(400);
                h(p, e, 6);
            }
            sp(p, ParticleTypes.SNOWFLAKE, p.getX(), p.getY() + 1, p.getZ(), 120, 3, 0.1);
        });
        c1("chispa_ignea", "Chispa Ignea", 8, p -> ray(p, p.getLookAngle(), 22, 1.0, 8, ParticleTypes.FLAME, true, true));
        c1("escudo_fugaz", "Escudo Fugaz", 30, p -> {
            fx(p, MobEffects.ABSORPTION, 20, 3);
            sp(p, ParticleTypes.ENCHANT, p.getX(), p.getY() + 1, p.getZ(), 60, 0.8, 0.5);
        });
        c1("paso_fantasma", "Paso Fantasma", 25, p -> {
            fx(p, MobEffects.INVISIBILITY, 10, 0);
            fx(p, MobEffects.MOVEMENT_SPEED, 10, 2);
        });
        c1("latigazo", "Latigazo Electrico", 10, p -> {
            Vec3 t = aim(p, 35);
            bolt(p, t);
            for (LivingEntity e : at(p, t, 3.5)) h(p, e, 16);
        });
        c1("lluvia_flechas", "Tormenta de Flechas", 14, p -> {
            Vec3 t = aim(p, 40);
            for (int i = 0; i < 14; i++) {
                Arrow a = new Arrow(p.level(), t.x + rnd(p, 4), t.y + 14 + p.getRandom().nextInt(6), t.z + rnd(p, 4));
                a.setOwner(p);
                a.setBaseDamage(7);
                a.pickup = AbstractArrow.Pickup.DISALLOWED;
                a.setDeltaMovement(0, -2.2, 0);
                p.level().addFreshEntity(a);
            }
        });
        c1("tremor", "Tremor", 12, p -> {
            for (LivingEntity e : n(p, 10)) {
                h(p, e, 8);
                push(p, e, 1.3, 0.45);
            }
            sp(p, ParticleTypes.EXPLOSION, p.getX(), p.getY() + 0.3, p.getZ(), 10, 3, 0);
        });
        c1("cura_rapida", "Cura Rapida", 20, p -> {
            p.heal(14);
            sp(p, ParticleTypes.HEART, p.getX(), p.getY() + 1.5, p.getZ(), 12, 0.5, 0.1);
        });
        c1("vision_caos", "Vision del Caos", 45, p -> {
            for (LivingEntity e : n(p, 40)) fx(e, MobEffects.GLOWING, 25, 0);
            fx(p, MobEffects.NIGHT_VISION, 30, 0);
        });
        c1("meteorito", "Meteorito", 16, p -> {
            Vec3 t = aim(p, 60);
            fire(p, t.x, t.y + 28, t.z, 4);
        });
        c1("mordisco", "Mordisco Vampirico", 14, p -> {
            if (ray(p, p.getLookAngle(), 7, 0.9, 14, ParticleTypes.CRIMSON_SPORE, false, true) > 0) p.heal(14);
        });
        c1("teletransporte", "Teletransporte Corto", 8, p -> {
            Vec3 t = aim(p, 18).subtract(p.getLookAngle().scale(0.6));
            p.teleportTo(t.x, t.y, t.z);
            sp(p, ParticleTypes.PORTAL, t.x, t.y + 1, t.z, 50, 0.4, 0.5);
        });
        c1("ancla_gravitatoria", "Ancla Gravitatoria", 15, p -> {
            for (LivingEntity e : n(p, 14)) {
                pull(p.position(), e, 1.4);
                fx(e, MobEffects.MOVEMENT_SLOWDOWN, 3, 1);
            }
        });
        c1("pulso_sonico", "Pulso Sonico", 12, p -> {
            for (LivingEntity e : n(p, 9)) {
                h(p, e, 10);
                fx(e, MobEffects.BLINDNESS, 4, 0);
                push(p, e, 1.0, 0.2);
            }
            sp(p, ParticleTypes.SONIC_BOOM, p.getX(), p.getY() + 1, p.getZ(), 1, 0, 0);
        });
        c1("piel_piedra", "Piel de Piedra", 35, p -> {
            fx(p, MobEffects.DAMAGE_RESISTANCE, 20, 2);
            fx(p, MobEffects.MOVEMENT_SLOWDOWN, 20, 0);
        });
        c1("furia", "Furia", 30, p -> fx(p, MobEffects.DAMAGE_BOOST, 15, 2));
        c1("rayo_solar", "Rayo Solar", 14, p -> ray(p, p.getLookAngle(), 28, 1.2, 16, ParticleTypes.END_ROD, true, true));
        c1("viento_cortante", "Viento Cortante", 9, p -> ray(p, p.getLookAngle(), 18, 1.8, 10, ParticleTypes.SWEEP_ATTACK, false, true));
        c1("lobos", "Manada Espectral", 40, p -> {
            for (int i = 0; i < 3; i++) {
                Wolf w = EntityType.WOLF.create(p.level());
                if (w == null) continue;
                w.moveTo(p.getX() + rnd(p, 2), p.getY(), p.getZ() + rnd(p, 2));
                w.tame(p);
                w.getPersistentData().putInt("nc_life", 600);
                p.level().addFreshEntity(w);
            }
        });
        c1("cadenas_sombra", "Cadenas de Sombra", 18, p -> {
            for (LivingEntity e : n(p, 11)) {
                fx(e, MobEffects.MOVEMENT_SLOWDOWN, 6, 6);
                fx(e, MobEffects.WEAKNESS, 6, 2);
                h(p, e, 3);
            }
        });
        c1("bomba_humo", "Bomba de Humo", 25, p -> {
            for (LivingEntity e : n(p, 9)) fx(e, MobEffects.BLINDNESS, 8, 0);
            fx(p, MobEffects.INVISIBILITY, 5, 0);
            sp(p, ParticleTypes.LARGE_SMOKE, p.getX(), p.getY() + 1, p.getZ(), 150, 3, 0.05);
        });
        c1("marea_venenosa", "Marea Venenosa", 18, p -> {
            for (LivingEntity e : n(p, 9)) {
                fx(e, MobEffects.POISON, 10, 2);
                fx(e, MobEffects.HUNGER, 10, 2);
            }
            sp(p, ParticleTypes.COMPOSTER, p.getX(), p.getY() + 1, p.getZ(), 120, 3, 0.05);
        });
        c1("lluvia_fuego", "Lluvia de Fuego", 18, p -> {
            Vec3 t = aim(p, 40);
            for (int i = 0; i < 8; i++) {
                SmallFireball f = new SmallFireball(p.level(), p, 0, -1, 0);
                f.setPos(t.x + rnd(p, 5), t.y + 16 + p.getRandom().nextInt(5), t.z + rnd(p, 5));
                f.setDeltaMovement(0, -1.3, 0);
                p.level().addFreshEntity(f);
            }
        });
        c1("triple_salto", "Salto Triple", 7, p -> {
            p.setDeltaMovement(p.getDeltaMovement().x, 1.7, p.getDeltaMovement().z);
            p.hurtMarked = true;
            fx(p, MobEffects.SLOW_FALLING, 8, 0);
        });
        c1("golpe_sismico", "Golpe Sismico", 13, p -> ray(p, flat(p), 18, 2.0, 18, ParticleTypes.CLOUD, false, true));
        c1("cazador", "Instinto de Cazador", 40, p -> {
            fx(p, MobEffects.MOVEMENT_SPEED, 30, 2);
            fx(p, MobEffects.JUMP, 30, 1);
            fx(p, MobEffects.NIGHT_VISION, 40, 0);
            for (LivingEntity e : n(p, 25)) fx(e, MobEffects.GLOWING, 20, 0);
        });
        c1("maldicion", "Maldicion Marchita", 12, p -> {
            for (LivingEntity e : at(p, aim(p, 30), 3.5)) {
                fx(e, MobEffects.WITHER, 10, 2);
                fx(e, MobEffects.WEAKNESS, 10, 1);
                h(p, e, 6);
            }
        });
        c1("cosecha_almas", "Cosecha de Almas", 20, p -> {
            float heal = 0;
            for (LivingEntity e : n(p, 10)) {
                h(p, e, 5);
                heal += 3;
            }
            p.heal(Math.min(heal, 18));
            sp(p, ParticleTypes.SOUL, p.getX(), p.getY() + 1, p.getZ(), 40, 2, 0.05);
        });
        c1("estallido_luz", "Estallido de Luz", 22, p -> {
            for (LivingEntity e : n(p, 12)) {
                fx(e, MobEffects.BLINDNESS, 5, 0);
                fx(e, MobEffects.GLOWING, 10, 0);
                h(p, e, 5);
            }
            p.heal(6);
            cleanse(p);
        });
        c1("congelacion", "Congelacion Temporal", 35, p -> {
            for (LivingEntity e : n(p, 12)) {
                fx(e, MobEffects.MOVEMENT_SLOWDOWN, 5, 9);
                e.setTicksFrozen(300);
                if (e instanceof Mob m) {
                    m.setNoAi(true);
                    m.getPersistentData().putInt("nc_unfreeze", 100);
                }
            }
        });
        c1("iman", "Iman de Botin", 30, p -> {
            for (ItemEntity i : p.level().getEntitiesOfClass(ItemEntity.class, p.getBoundingBox().inflate(24))) i.setPos(p.getX(), p.getY(), p.getZ());
            for (ExperienceOrb o : p.level().getEntitiesOfClass(ExperienceOrb.class, p.getBoundingBox().inflate(24))) o.setPos(p.getX(), p.getY(), p.getZ());
        });
        c1("eco_sonico", "Eco Sonico", 11, p -> ray(p, p.getLookAngle(), 30, 1.0, 12, ParticleTypes.SONIC_BOOM, false, true));
        c1("anillo_fuego", "Anillo de Fuego", 20, p -> {
            for (LivingEntity e : n(p, 7)) {
                e.setSecondsOnFire(8);
                h(p, e, 8);
                push(p, e, 1.2, 0.3);
            }
            sp(p, ParticleTypes.FLAME, p.getX(), p.getY() + 0.5, p.getZ(), 200, 4, 0.1);
        });
        c1("gravedad_cero", "Gravedad Cero", 25, p -> {
            for (LivingEntity e : n(p, 11)) {
                fx(e, MobEffects.LEVITATION, 4, 3);
                h(p, e, 3);
            }
        });
        c1("corte_etereo", "Corte Etereo", 9, p -> {
            for (int i = -3; i <= 3; i++) {
                ray(p, p.getLookAngle().yRot((float) Math.toRadians(i * 10)), 7, 1.0, 6, ParticleTypes.SWEEP_ATTACK, false, true);
            }
        });
        c1("rafaga", "Rafaga Veloz", 12, p -> {
            LivingEntity t = nearest(p, 6);
            if (t != null) for (int i = 0; i < 8; i++) h(p, t, 4);
        });

        // ---------------- Caos nivel 2 (Excalibur)
        c2("corte_dimensional", "Corte Dimensional", 20, p -> {
            ray(p, p.getLookAngle(), 55, 2.5, 80, ParticleTypes.END_ROD, false, true);
            ray(p, p.getLookAngle(), 55, 2.5, 0, ParticleTypes.SWEEP_ATTACK, false, true);
        });
        c2("tormenta_caos", "Tormenta del Caos", 40, p -> {
            Vec3 t = aim(p, 50);
            for (int i = 0; i < 10; i++) {
                Vec3 q = t.add(rnd(p, 10), 0, rnd(p, 10));
                bolt(p, q);
                for (LivingEntity e : at(p, q, 3)) h(p, e, 30);
            }
        });
        c2("colapso", "Colapso Gravitatorio", 35, p -> {
            Vec3 t = aim(p, 40);
            for (LivingEntity e : at(p, t, 16)) {
                pull(t, e, 1.6);
                fx(e, MobEffects.WITHER, 4, 1);
                h(p, e, 14);
            }
            sp(p, ParticleTypes.REVERSE_PORTAL, t.x, t.y + 1, t.z, 200, 2, 0.5);
        });
        c2("reloj_caos", "Reloj del Caos", 60, p -> {
            for (LivingEntity e : n(p, 26)) {
                fx(e, MobEffects.MOVEMENT_SLOWDOWN, 12, 8);
                fx(e, MobEffects.WEAKNESS, 12, 3);
                fx(e, MobEffects.DIG_SLOWDOWN, 12, 3);
            }
            fx(p, MobEffects.MOVEMENT_SPEED, 12, 4);
            fx(p, MobEffects.DIG_SPEED, 12, 3);
        });
        c2("lluvia_meteoritos", "Lluvia de Meteoritos", 45, p -> {
            Vec3 t = aim(p, 60);
            for (int i = 0; i < 7; i++) fire(p, t.x + rnd(p, 10), t.y + 30 + i * 3, t.z + rnd(p, 10), 3);
        });
        c2("aura_aniquiladora", "Aura Aniquiladora", 70, p -> PD.puti(p, "nc_aura", 300));
        c2("resurgir", "Resurgir del Caos", 90, p -> {
            p.setHealth(p.getMaxHealth());
            cleanse(p);
            fx(p, MobEffects.ABSORPTION, 30, 4);
            fx(p, MobEffects.DAMAGE_RESISTANCE, 30, 2);
        });
        c2("furia_primigenia", "Furia Primigenia", 50, p -> {
            fx(p, MobEffects.DAMAGE_BOOST, 20, 4);
            fx(p, MobEffects.MOVEMENT_SPEED, 20, 3);
            fx(p, MobEffects.DAMAGE_RESISTANCE, 20, 1);
        });
        c2("dominio_sombras", "Dominio de las Sombras", 40, p -> {
            for (LivingEntity e : n(p, 20)) {
                fx(e, MobEffects.WITHER, 8, 3);
                fx(e, MobEffects.BLINDNESS, 8, 0);
                fx(e, MobEffects.MOVEMENT_SLOWDOWN, 8, 3);
                h(p, e, 20);
            }
        });
        c2("lanzas_caos", "Lanzas del Caos", 18, p -> {
            for (int i = -3; i <= 3; i++) {
                ray(p, p.getLookAngle().yRot((float) Math.toRadians(i * 7)), 45, 1.0, 45, ParticleTypes.WITCH, false, true);
            }
        });
        c2("supernova", "Supernova", 60, p -> {
            for (LivingEntity e : n(p, 20)) {
                h(p, e, 90);
                push(p, e, 3, 0.8);
            }
            sp(p, ParticleTypes.EXPLOSION_EMITTER, p.getX(), p.getY() + 1, p.getZ(), 3, 4, 0);
            boom(p);
        });
        c2("puerta_dimensional", "Puerta Dimensional", 25, p -> {
            Vec3 t = aim(p, 110).subtract(p.getLookAngle().scale(1));
            p.teleportTo(t.x, t.y, t.z);
            sp(p, ParticleTypes.REVERSE_PORTAL, t.x, t.y + 1, t.z, 80, 0.5, 0.5);
        });

        // ---------------- Caos nivel 3 (Cath Palug)
        c3("absorcion_caos", "Absorcion del Caos", 60, p -> {
            float heal = 0;
            for (LivingEntity e : n(p, 32)) {
                h(p, e, 150);
                heal += 25;
            }
            p.heal(Math.min(heal, 60));
            fx(p, MobEffects.ABSORPTION, 30, 4);
        });
        c3("fin_tiempos", "El Fin de los Tiempos", 120, p -> {
            fx(p, MobEffects.DAMAGE_RESISTANCE, 6, 4);
            for (LivingEntity e : n(p, 45)) {
                h(p, e, 350);
                fx(e, MobEffects.MOVEMENT_SLOWDOWN, 10, 9);
                fx(e, MobEffects.WEAKNESS, 10, 4);
            }
        });
        c3("rey_caos", "Rey del Caos", 180, p -> {
            fx(p, MobEffects.DAMAGE_BOOST, 90, 8);
            fx(p, MobEffects.DAMAGE_RESISTANCE, 90, 3);
            fx(p, MobEffects.MOVEMENT_SPEED, 90, 3);
            fx(p, MobEffects.REGENERATION, 90, 4);
            fx(p, MobEffects.FIRE_RESISTANCE, 90, 0);
            fx(p, MobEffects.ABSORPTION, 90, 9);
        });
        c3("cataclismo", "Cataclismo", 90, p -> {
            fx(p, MobEffects.DAMAGE_RESISTANCE, 4, 4);
            Vec3 t = aim(p, 80);
            for (LivingEntity e : at(p, t, 14)) h(p, e, 220);
            for (int i = 0; i < 12; i++) {
                Vec3 q = t.add(rnd(p, 12), 0, rnd(p, 12));
                p.level().explode(null, q.x, q.y, q.z, 4.5f, Level.ExplosionInteraction.TNT);
            }
        });
        c3("singularidad", "Singularidad", 100, p -> {
            Vec3 t = aim(p, 60);
            for (LivingEntity e : at(p, t, 30)) {
                pull(t, e, 2.2);
                h(p, e, 70);
                fx(e, MobEffects.WITHER, 6, 4);
            }
            sp(p, ParticleTypes.REVERSE_PORTAL, t.x, t.y + 1, t.z, 300, 3, 0.5);
        });
        c3("renacer_caos", "Renacer del Caos", 240, p -> PD.puti(p, "nc_rebirth", 1200));
    }
}
