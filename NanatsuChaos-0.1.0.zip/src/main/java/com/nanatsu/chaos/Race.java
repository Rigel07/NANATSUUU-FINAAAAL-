package com.nanatsu.chaos;

public enum Race {
    NONE("Sin raza", 0xFFFFFF, new String[]{}),
    HUMANO("Humano", 0xF5C77E, new String[]{
            "Voluntad que no se rinde.",
            "+Suerte y +50% de fragmentos del Caos.",
            "Regenera cuando le queda poca vida.",
            "Habilidad: Voluntad Humana."}),
    GIGANTE("Gigante", 0xB08A5E, new String[]{
            "Cuerpo colosal y fuerza bruta.",
            "+Vida, +Dano, +Alcance y casi sin retroceso.",
            "Habilidad: Pisoton Gigante.",
            "Documento perdido: Metal Pesado."}),
    DEMONIO("Demonio", 0xD02A55, new String[]{
            "Sangre del Clan de los Demonios.",
            "Mas fuerte de noche. 3 niveles de demonio.",
            "Marcas demoniacas al subir de nivel.",
            "Habilidad: Llama Oscura. Documento: Nebulosa Oscura."}),
    HADA("Hada", 0x7BE0A5, new String[]{
            "Ligera, veloz y afortunada.",
            "Sin dano por caida y saltos enormes.",
            "Habilidad: Polvo de Hada (vuelo).",
            "Documento perdido: Danza de Petalos."}),
    DIOSA("Diosa", 0xF3E3FF, new String[]{
            "Poder divino y bendicion.",
            "+Vida, regeneracion e inmunidad al fuego.",
            "Habilidad: Bendicion Divina.",
            "Documento perdido: Juicio Divino."});

    public final String label;
    public final int color;
    public final String[] lines;

    Race(String label, int color, String[] lines) {
        this.label = label;
        this.color = color;
        this.lines = lines;
    }

    public static Race of(String s) {
        try {
            return valueOf(s);
        } catch (Exception e) {
            return NONE;
        }
    }
}
