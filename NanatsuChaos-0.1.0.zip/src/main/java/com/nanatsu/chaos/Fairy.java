package com.nanatsu.chaos;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomFlyingGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;

/** Hada del bosque del Rey Hada. El Rey Hada es una hada grande que regala fragmentos del Caos. */
public class Fairy extends PathfinderMob {
    static final EntityDataAccessor<Boolean> KING = SynchedEntityData.defineId(Fairy.class, EntityDataSerializers.BOOLEAN);

    public Fairy(EntityType<? extends PathfinderMob> t, Level l) {
        super(t, l);
        this.moveControl = new FlyingMoveControl(this, 20, true);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder attrs() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 10).add(Attributes.MOVEMENT_SPEED, 0.25)
                .add(Attributes.FLYING_SPEED, 0.6);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(KING, false);
    }

    public boolean isKing() { return this.entityData.get(KING); }

    public void makeKing() {
        this.entityData.set(KING, true);
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(80);
        setHealth(80f);
        setCustomName(Component.literal("Rey Hada"));
    }

    @Override
    protected PathNavigation createNavigation(Level l) {
        FlyingPathNavigation n = new FlyingPathNavigation(this, l);
        n.setCanOpenDoors(false);
        n.setCanFloat(true);
        n.setCanPassDoors(true);
        return n;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(2, new WaterAvoidingRandomFlyingGoal(this, 1.0));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8f));
    }

    @Override
    public InteractionResult mobInteract(Player p, InteractionHand h) {
        if (!level().isClientSide && p instanceof ServerPlayer sp) {
            if (isKing()) {
                var d = PD.t(sp);
                long now = level().getGameTime();
                if (now - d.getLong("king_gift") > 24000 || d.getLong("king_gift") > now) {
                    d.putLong("king_gift", now);
                    sp.addItem(new ItemStack(Reg.FRAGMENT.get(), 2));
                    sp.addEffect(new MobEffectInstance(MobEffects.LUCK, 6000, 1));
                    sp.sendSystemMessage(Component.literal("§aRey Hada: §fQue el bosque te bendiga, viajero."));
                } else {
                    sp.sendSystemMessage(Component.literal("§aRey Hada: §fVuelve manana, viajero."));
                }
            } else {
                sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 1200, 1));
            }
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override public boolean causeFallDamage(float f, float m, DamageSource s) { return false; }
    @Override protected void checkFallDamage(double y, boolean g, BlockState s, BlockPos p) { }
    @Override protected SoundEvent getAmbientSound() { return SoundEvents.ALLAY_AMBIENT_WITHOUT_ITEM; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.ALLAY_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.ALLAY_DEATH; }
    @Override public boolean removeWhenFarAway(double d) { return false; }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        t.putBoolean("King", isKing());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        if (t.getBoolean("King")) this.entityData.set(KING, true);
    }
}
