package com.nanatsu.chaos;

import java.util.Optional;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

/** Ilusion de un jugador (Lostvayne): ataca a los enemigos y desaparece al recibir cualquier dano. */
public class IllusionClone extends PathfinderMob {
    static final EntityDataAccessor<Optional<UUID>> OWNER =
            SynchedEntityData.defineId(IllusionClone.class, EntityDataSerializers.OPTIONAL_UUID);
    int life = 400;

    public IllusionClone(EntityType<? extends PathfinderMob> t, Level l) {
        super(t, l);
    }

    public static AttributeSupplier.Builder attrs() {
        return Mob.createMobAttributes().add(Attributes.MAX_HEALTH, 2).add(Attributes.MOVEMENT_SPEED, 0.36)
                .add(Attributes.ATTACK_DAMAGE, 14).add(Attributes.FOLLOW_RANGE, 24);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(OWNER, Optional.empty());
    }

    public void setOwner(Player p) { this.entityData.set(OWNER, Optional.of(p.getUUID())); }
    public Optional<UUID> getOwnerId() { return this.entityData.get(OWNER); }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.3, true));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Mob.class, 10, true, false, e -> e instanceof Enemy));
    }

    @Override
    public boolean hurt(DamageSource s, float a) {
        if (s.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(s, a);
        if (!level().isClientSide) vanish();
        return true;
    }

    private void vanish() {
        ((ServerLevel) level()).sendParticles(ParticleTypes.POOF, getX(), getY() + 1, getZ(), 20, 0.3, 0.5, 0.3, 0.05);
        discard();
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && --life <= 0) vanish();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag t) {
        super.addAdditionalSaveData(t);
        getOwnerId().ifPresent(u -> t.putUUID("Owner", u));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag t) {
        super.readAdditionalSaveData(t);
        if (t.hasUUID("Owner")) this.entityData.set(OWNER, Optional.of(t.getUUID("Owner")));
    }
}
