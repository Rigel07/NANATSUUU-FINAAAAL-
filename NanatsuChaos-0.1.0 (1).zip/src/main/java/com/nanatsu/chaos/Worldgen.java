package com.nanatsu.chaos;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Estructuras colocadas por codigo (statues, Liones, bosque del Rey Hada, Excalibur...). */
public final class Worldgen {
    private Worldgen() {}

    static BlockState s(net.minecraft.world.level.block.Block b) { return b.defaultBlockState(); }

    static void set(WorldGenLevel l, BlockPos p, BlockState st) { l.setBlock(p, st, 2); }

    static void box(WorldGenLevel l, BlockPos o, int x1, int y1, int z1, int x2, int y2, int z2, BlockState st) {
        for (int x = x1; x <= x2; x++)
            for (int y = y1; y <= y2; y++)
                for (int z = z1; z <= z2; z++)
                    set(l, o.offset(x, y, z), st);
    }

    static void air(WorldGenLevel l, BlockPos o, int x1, int y1, int z1, int x2, int y2, int z2) {
        box(l, o, x1, y1, z1, x2, y2, z2, s(Blocks.AIR));
    }

    static boolean flat(WorldGenLevel l, BlockPos o, int r, int tol) {
        int[][] pts = {{-r, -r}, {r, -r}, {-r, r}, {r, r}, {0, 0}};
        for (int[] q : pts) {
            int h = l.getHeight(Heightmap.Types.WORLD_SURFACE_WG, o.getX() + q[0], o.getZ() + q[1]);
            if (Math.abs(h - o.getY()) > tol) return false;
        }
        return l.getFluidState(o.below()).isEmpty() && l.getFluidState(o).isEmpty();
    }

    /** Plataforma circular con relleno por debajo y espacio libre por encima. */
    static void platform(WorldGenLevel l, BlockPos o, int r, BlockState top) {
        for (int x = -r; x <= r; x++)
            for (int z = -r; z <= r; z++) {
                if (x * x + z * z > r * r) continue;
                set(l, o.offset(x, -1, z), top);
                for (int y = -2; y >= -5; y--) set(l, o.offset(x, y, z), s(Blocks.DIRT));
                for (int y = 0; y <= 5; y++) set(l, o.offset(x, y, z), s(Blocks.AIR));
            }
    }

    static void pad(WorldGenLevel l, BlockPos o, int x1, int z1, int x2, int z2, BlockState top) {
        for (int x = x1; x <= x2; x++)
            for (int z = z1; z <= z2; z++) {
                set(l, o.offset(x, -1, z), top);
                for (int y = -2; y >= -5; y--) set(l, o.offset(x, y, z), s(Blocks.DIRT));
            }
    }

    static <T extends Mob> void spawn(WorldGenLevel l, EntityType<T> t, double x, double y, double z) {
        T m = t.create(l.getLevel());
        if (m == null) return;
        m.moveTo(x, y, z, l.getRandom().nextFloat() * 360f, 0f);
        m.finalizeSpawn(l, l.getCurrentDifficultyAt(BlockPos.containing(x, y, z)), MobSpawnType.STRUCTURE, null, null);
        m.setPersistenceRequired();
        l.addFreshEntity(m);
    }

    static void chest(WorldGenLevel l, BlockPos p, String table) {
        set(l, p, s(Blocks.CHEST));
        BlockEntity be = l.getBlockEntity(p);
        if (be instanceof RandomizableContainerBlockEntity c) {
            c.setLootTable(new ResourceLocation(NanatsuChaos.MODID, "chests/" + table), l.getRandom().nextLong());
        }
    }

    static BlockState statue(String id) { return Reg.B.get(id).get().defaultBlockState(); }

    // ------------------------------------------------------------------ estatuas de los 7 pecados y Hawk
    public static class SinStatues extends Feature<NoneFeatureConfiguration> {
        public SinStatues() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 7, 3)) return false;
            platform(l, o, 7, s(Blocks.STONE_BRICKS));
            String[] ids = {"meliodas", "diane", "ban", "king", "gowther", "merlin", "escanor"};
            for (int i = 0; i < 7; i++) {
                double a = Math.PI * 2 * i / 7;
                BlockPos q = o.offset((int) Math.round(Math.cos(a) * 5), 0, (int) Math.round(Math.sin(a) * 5));
                set(l, q, statue("estatua_" + ids[i]));
                set(l, q.below(), s(Blocks.POLISHED_ANDESITE));
                BlockPos lp = o.offset((int) Math.round(Math.cos(a) * 6.5), 0, (int) Math.round(Math.sin(a) * 6.5));
                set(l, lp, s(Blocks.STONE_BRICK_WALL));
                set(l, lp.above(), s(Blocks.LANTERN));
            }
            box(l, o, -1, -1, -1, 1, -1, 1, s(Blocks.GOLD_BLOCK));
            set(l, o, statue("estatua_hawk"));
            spawn(l, Reg.HAWK.get(), o.getX() + 2.5, o.getY(), o.getZ() + 0.5);
            return true;
        }
    }

    // ------------------------------------------------------------------ santuario de un arcangel (da una Gracia)
    public static class Archangel extends Feature<NoneFeatureConfiguration> {
        public Archangel() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 4, 3)) return false;
            platform(l, o, 4, s(Blocks.QUARTZ_BLOCK));
            String[] ids = {"sol", "brillo", "oceano", "viento"};
            set(l, o, statue("arcangel_" + ids[l.getRandom().nextInt(4)]));
            set(l, o.below(), s(Blocks.CHISELED_QUARTZ_BLOCK));
            int[][] corners = {{-3, -3}, {3, -3}, {-3, 3}, {3, 3}};
            for (int[] q : corners) {
                box(l, o, q[0], 0, q[1], q[0], 3, q[1], s(Blocks.QUARTZ_PILLAR));
                set(l, o.offset(q[0], 4, q[1]), s(Blocks.SEA_LANTERN));
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ Excalibur en la piedra
    public static class ExcaliburStone extends Feature<NoneFeatureConfiguration> {
        public ExcaliburStone() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 4, 2)) return false;
            platform(l, o, 4, s(Blocks.MOSS_BLOCK));
            set(l, o.below(), s(Blocks.MOSSY_COBBLESTONE));
            set(l, o, statue("piedra_excalibur"));
            int[][] st = {{-3, 0}, {3, 0}, {0, -3}, {0, 3}};
            for (int[] q : st) {
                box(l, o, q[0], 0, q[1], q[0], 2, q[1], s(Blocks.COBBLESTONE_WALL));
                set(l, o.offset(q[0], 3, q[1]), s(Blocks.LANTERN));
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ santuario de tesoro sagrado
    public static class TreasureShrine extends Feature<NoneFeatureConfiguration> {
        public TreasureShrine() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 3, 2)) return false;
            platform(l, o, 3, s(Blocks.DEEPSLATE_BRICKS));
            chest(l, o, "treasure_shrine");
            int[][] corners = {{-2, -2}, {2, -2}, {-2, 2}, {2, 2}};
            for (int[] q : corners) {
                box(l, o, q[0], 0, q[1], q[0], 2, q[1], s(Blocks.POLISHED_DEEPSLATE));
                set(l, o.offset(q[0], 3, q[1]), s(Blocks.SOUL_LANTERN));
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ ciudad de Liones: castillo + taberna de Escanor
    public static class Liones extends Feature<NoneFeatureConfiguration> {
        public Liones() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 6, 3)) return false;
            BlockState sb = s(Blocks.STONE_BRICKS);
            // terreno plano y despejado: castillo (-6..6) y taberna (7..15)
            pad(l, o, -6, -6, 6, 6, s(Blocks.POLISHED_ANDESITE));
            air(l, o, -6, 0, -6, 6, 12, 6);
            // muralla
            for (int i = -6; i <= 6; i++) {
                for (int y = 0; y <= 5; y++) {
                    set(l, o.offset(i, y, -6), sb);
                    set(l, o.offset(i, y, 6), sb);
                    set(l, o.offset(-6, y, i), sb);
                    set(l, o.offset(6, y, i), sb);
                }
                if (i % 2 == 0) {
                    set(l, o.offset(i, 6, -6), sb);
                    set(l, o.offset(i, 6, 6), sb);
                    set(l, o.offset(-6, 6, i), sb);
                    set(l, o.offset(6, 6, i), sb);
                }
            }
            // torres en las esquinas
            int[][] cs = {{-6, -6}, {6, -6}, {-6, 6}, {6, 6}};
            for (int[] q : cs) {
                for (int x = -1; x <= 1; x++)
                    for (int z = -1; z <= 1; z++) {
                        for (int y = 0; y <= 8; y++) {
                            boolean edge = Math.abs(x) == 1 || Math.abs(z) == 1;
                            set(l, o.offset(q[0] + x, y, q[1] + z), edge ? sb : s(Blocks.AIR));
                        }
                        if ((x + z) % 2 == 0) set(l, o.offset(q[0] + x, 9, q[1] + z), sb);
                    }
                set(l, o.offset(q[0], 10, q[1]), s(Blocks.LANTERN));
            }
            // puerta sur (z = +6)
            air(l, o, -1, 0, 6, 1, 3, 6);
            // torre del homenaje 5x5
            for (int x = -2; x <= 2; x++)
                for (int z = -2; z <= 2; z++) {
                    boolean edge = Math.abs(x) == 2 || Math.abs(z) == 2;
                    for (int y = 0; y <= 7; y++) set(l, o.offset(x, y, z), edge ? s(Blocks.STONE_BRICKS) : s(Blocks.AIR));
                    set(l, o.offset(x, 8, z), s(Blocks.BLUE_WOOL));
                }
            air(l, o, 0, 0, 2, 0, 1, 2);
            chest(l, o.offset(0, 0, -1), "liones");
            set(l, o.offset(1, 0, -1), s(Blocks.LANTERN));
            // taberna 9x9 centrada en x=11
            BlockPos t = o.offset(11, 0, 0);
            pad(l, t, -4, -4, 4, 4, s(Blocks.OAK_PLANKS));
            air(l, t, -4, 0, -4, 4, 8, 4);
            for (int x = -4; x <= 4; x++)
                for (int z = -4; z <= 4; z++) {
                    boolean wall = Math.abs(x) == 4 || Math.abs(z) == 4;
                    boolean corner = Math.abs(x) == 4 && Math.abs(z) == 4;
                    for (int y = 0; y <= 3; y++) {
                        if (corner) set(l, t.offset(x, y, z), s(Blocks.STRIPPED_SPRUCE_LOG));
                        else if (wall) set(l, t.offset(x, y, z), s(Blocks.SPRUCE_PLANKS));
                    }
                    set(l, t.offset(x, 4, z), s(Blocks.SPRUCE_SLAB));
                }
            air(l, t, -4, 0, 0, -4, 1, 0);
            box(l, t, 1, 0, 1, 3, 0, 1, s(Blocks.SPRUCE_SLAB));
            box(l, t, 3, 0, -3, 3, 0, -1, s(Blocks.BARREL));
            set(l, t.offset(-3, 0, 3), s(Blocks.BARREL));
            set(l, t.offset(-3, 0, -3), s(Blocks.BARREL));
            set(l, t.offset(-2, 0, 2), s(Blocks.OAK_FENCE));
            set(l, t.offset(-2, 1, 2), s(Blocks.OAK_PRESSURE_PLATE));
            set(l, t.offset(0, 0, -2), s(Blocks.OAK_FENCE));
            set(l, t.offset(0, 1, -2), s(Blocks.OAK_PRESSURE_PLATE));
            set(l, t.offset(-3, 0, 0), s(Blocks.LANTERN));
            set(l, t.offset(2, 0, 3), s(Blocks.LANTERN));
            // habitantes
            spawn(l, Reg.ESCANOR.get(), t.getX() + 2.5, t.getY(), t.getZ() + 0.5);
            spawn(l, Reg.HAWK.get(), t.getX() - 1.5, t.getY(), t.getZ() + 2.5);
            for (int i = 0; i < 3; i++) spawn(l, Reg.KNIGHT.get(), o.getX() - 1.5 + i * 1.5, o.getY(), o.getZ() + 8.5);
            return true;
        }
    }

    // ------------------------------------------------------------------ bosque del Rey Hada
    public static class FairyForest extends Feature<NoneFeatureConfiguration> {
        public FairyForest() { super(NoneFeatureConfiguration.CODEC); }

        @Override
        public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> c) {
            WorldGenLevel l = c.level();
            BlockPos o = c.origin();
            if (!flat(l, o, 8, 6)) return false;
            // musgo en el suelo
            for (int x = -13; x <= 13; x++)
                for (int z = -13; z <= 13; z++) {
                    if (x * x + z * z > 169) continue;
                    int h = l.getHeight(Heightmap.Types.WORLD_SURFACE_WG, o.getX() + x, o.getZ() + z);
                    BlockPos g = new BlockPos(o.getX() + x, h - 1, o.getZ() + z);
                    if (l.getFluidState(g).isEmpty() && l.getBlockState(g).isSolid()) {
                        set(l, g, s(Blocks.MOSS_BLOCK));
                        if (l.getRandom().nextInt(4) == 0) set(l, g.above(), s(Blocks.PINK_PETALS));
                        else if (l.getRandom().nextInt(6) == 0) set(l, g.above(), s(Blocks.MOSS_CARPET));
                    }
                }
            // arboles luminosos
            for (int i = 0; i < 14; i++) {
                int x = l.getRandom().nextInt(25) - 12, z = l.getRandom().nextInt(25) - 12;
                if (Math.abs(x) < 4 && Math.abs(z) < 4) continue;
                if (x * x + z * z > 150) continue;
                int h = l.getHeight(Heightmap.Types.WORLD_SURFACE_WG, o.getX() + x, o.getZ() + z);
                BlockPos b = new BlockPos(o.getX() + x, h, o.getZ() + z);
                int th = 6 + l.getRandom().nextInt(4);
                for (int y = 0; y < th; y++) set(l, b.above(y), s(Blocks.CHERRY_LOG));
                for (int dx = -3; dx <= 3; dx++)
                    for (int dy = -2; dy <= 2; dy++)
                        for (int dz = -3; dz <= 3; dz++) {
                            if (dx * dx + dy * dy * 2 + dz * dz > 11) continue;
                            BlockPos lp = b.offset(dx, th - 1 + dy, dz);
                            if (l.getBlockState(lp).isAir()) set(l, lp, s(Blocks.CHERRY_LEAVES));
                        }
                set(l, b.offset(1, th - 2, 0), s(Blocks.SHROOMLIGHT));
                set(l, b.offset(-1, th - 3, 1), s(Blocks.SHROOMLIGHT));
            }
            // trono del Rey Hada
            pad(l, o, -3, -3, 3, 3, s(Blocks.QUARTZ_BLOCK));
            air(l, o, -3, 0, -3, 3, 6, 3);
            box(l, o, -1, 0, 1, 1, 0, 1, s(Blocks.QUARTZ_SLAB));
            box(l, o, -1, 1, 1, 1, 3, 1, s(Blocks.QUARTZ_PILLAR));
            set(l, o, s(Blocks.QUARTZ_STAIRS));
            set(l, o.offset(0, 1, 0), s(Blocks.GLOWSTONE));
            chest(l, o.offset(2, 0, -2), "fairy");
            Fairy king = Reg.FAIRY.get().create(l.getLevel());
            if (king != null) {
                king.moveTo(o.getX() + 0.5, o.getY() + 2, o.getZ() + 0.5, 0f, 0f);
                king.finalizeSpawn(l, l.getCurrentDifficultyAt(o), MobSpawnType.STRUCTURE, null, null);
                king.makeKing();
                l.addFreshEntity(king);
            }
            for (int i = 0; i < 6; i++) {
                spawn(l, Reg.FAIRY.get(), o.getX() + l.getRandom().nextInt(13) - 6, o.getY() + 2 + l.getRandom().nextInt(3), o.getZ() + l.getRandom().nextInt(13) - 6);
            }
            return true;
        }
    }
}
